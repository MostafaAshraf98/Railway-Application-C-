---------------CREATE DATABASE----------
CREATE DATABASE RAILWAY
GO
USE RAILWAY

-------------CREATE TABLES--------------

CREATE TABLE PASSENGER
(
  Fname VARCHAR(50) NOT NULL,
  Minit CHAR(1) NOT NULL,
  Lname VARCHAR(50) NOT NULL,
  Sex CHAR(1) NOT NULL,
  P_SSN BIGINT NOT NULL,
  Phone_Number BIGINT NOT NULL,
  DOB DATE NOT NULL,
  PRIMARY KEY (P_SSN),
  UNIQUE (Phone_Number)
);

CREATE TABLE EMPLOYEE
(
  Fname VARCHAR(50) NOT NULL,
  Minit CHAR(1) NOT NULL,
  Lname VARCHAR(50) NOT NULL,
  E_SSN BIGINT NOT NULL,
  Sex CHAR(1) NOT NULL,
  Phone_Number BIGINT NOT NULL,
  Salary INT NOT NULL,
  DOB DATE NOT NULL,
  Manager_SSN BIGINT,
  FOREIGN KEY (Manager_SSN) REFERENCES EMPLOYEE (E_SSN),
  PRIMARY KEY (E_SSN),
  UNIQUE (Phone_Number)
);

CREATE TABLE TRAIN
(
  Business_Class INT NOT NULL,
  Economic_Class INT NOT NULL,
  Train_Number INT NOT NULL,
  Maintenance_Day DATE NOT NULL,
  PRIMARY KEY (Train_Number)
);

CREATE TABLE STATION
(
  Station_Name VARCHAR(50) NOT NULL,
  Station_Number INT NOT NULL,
  Location VARCHAR(50) NOT NULL,
  Manager_SSN BIGINT NOT NULL,
  Manager_Start_Date DATE NOT NULL,
  FOREIGN KEY (Manager_SSN) REFERENCES EMPLOYEE (E_SSN),
  PRIMARY KEY (Station_Number),
  UNIQUE (Station_Number)
);

ALTER TABLE EMPLOYEE ADD Station_Number INT,
FOREIGN KEY (Station_Number) REFERENCES STATION (Station_Number);

CREATE TABLE TRIP
(
  Trip_Number INT NOT NULL,
  Departure_Time TIME NOT NULL,
  Arrival_Time TIME NOT NULL,
  Economic_Ticket_Price INT NOT NULL,
  Business_Ticket_Price INT NOT NULL,
  Business INT NOT NULL,
  Economic INT NOT NULL,
  Train_Number INT NOT NULL,
  PRIMARY KEY (Trip_Number),
  FOREIGN KEY (Train_Number) REFERENCES TRAIN (Train_Number)
);

CREATE TABLE SUPPLIER
(
  Supplier_ID INT NOT NULL,
  Supplier_Address VARCHAR(50) NOT NULL,
  Supplier_Name VARCHAR(50) NOT NULL,
  Phone_Number BIGINT NOT NULL,
  PRIMARY KEY (Supplier_ID),
  UNIQUE (Phone_Number)
);

CREATE TABLE SPARE_PART
(
  Part_Number INT NOT NULL,
  Price INT NOT NULL,
  Supplier_ID INT NOT NULL,
  FOREIGN KEY (Supplier_ID) REFERENCES SUPPLIER (Supplier_ID),
  PRIMARY KEY (Part_Number)
);


CREATE TABLE BOOKINGS
(
  P_SSN BIGINT NOT NULL,
  Trip_Number INT NOT NULL,
  Trip_Date DATE NOT NULL,
  Type VARCHAR(8) NOT NULL,
  Status VARCHAR(10) NOT NULL,
  Feedback_Rating INT,
  Feedback_Comment VARCHAR(100),
  FOREIGN KEY (P_SSN) REFERENCES PASSENGER (P_SSN),
  FOREIGN KEY (Trip_Number) REFERENCES TRIP (Trip_Number),
  PRIMARY KEY (P_SSN,Trip_Number,Trip_Date)
);

CREATE TABLE FROM_TO
(
  Trip_Number INT NOT NULL,
  Station_Number1 INT NOT NULL,
  Station_Number2 INT NOT NULL
  FOREIGN KEY (Trip_Number) REFERENCES TRIP (Trip_Number),
  FOREIGN KEY (Station_Number1) REFERENCES STATION( Station_Number),
  FOREIGN KEY (Station_Number2) REFERENCES STATION( Station_Number),
  PRIMARY KEY (Trip_Number,Station_Number1,Station_Number2)
);

CREATE TABLE INVENTORY 
(
  Station_Number INT NOT NULL,
  Part_Number INT NOT NULL,
  Quantity INT,
  FOREIGN KEY (Station_Number) REFERENCES STATION( Station_Number),
  FOREIGN KEY (Part_Number) REFERENCES SPARE_PART (Part_Number),
  PRIMARY KEY (Station_Number,Part_Number)
);

CREATE TABLE REQUEST 
(
  E_SSN BIGINT NOT NULL,
  Part_Number INT NOT NULL,
  Request_ID INT NOT NULL,
  Quantity INT,
  Status VARCHAR(10) NOT NULL,
  FOREIGN KEY (E_SSN) REFERENCES EMPLOYEE (E_SSN),
  FOREIGN KEY (Part_Number) REFERENCES SPARE_PART (Part_Number),
  PRIMARY KEY (Request_ID)
);

CREATE TABLE LOGIN_PASSENGER
(
  P_SSN BIGINT NOT NULL,
  Username VARCHAR(50) NOT NULL,
  Password VARCHAR(50) NOT NULL,
  UNIQUE (P_SSN),
  FOREIGN KEY (P_SSN) REFERENCES PASSENGER (P_SSN),
  PRIMARY KEY (Username)
);

CREATE TABLE LOGIN_EMPLOYEE
(
  E_SSN BIGINT NOT NULL,
  Username VARCHAR(50) NOT NULL,
  Password VARCHAR(50) NOT NULL,
  UNIQUE (E_SSN),
  FOREIGN KEY (E_SSN) REFERENCES EMPLOYEE (E_SSN),
  PRIMARY KEY (Username)
);

---------------------ADDING ROWS INTO THE DB-------------

INSERT INTO EMPLOYEE(Fname,Minit,Lname,E_SSN,Sex,Phone_Number,Salary,DOB,Manager_SSN)
VALUES
--DELETE FROM EMPLOYEE
('Ahmed','M','Ismail',12345678911234,'M',01123456789,30000,'2000-02-22',NULL),
('Moaz','M','ElSherbiny',12345678911274,'M',0114789542,30000,'2000-10-03',12345678911234),
('Mostafa','A','Ahmed',72345678911234,'M',01158795123,30000,'1998-12-12',12345678911234),
('Nader','Y','Adib',12786789112341,'M',01285003523,30000,'2000-05-15',NULL),
('Salma','O','Ahmed',47127867891123,'F',012789614587,25000,'1995-03-06',NULL),
('Hesham','I','Mohamed',95212786789112,'M',011478213457,10000,'2000-01-04',12345678911234),
('Ali','A','Mahmoud',18345678914574,'M',015896547812,20000,'1998-03-01',12786789112341),
('Omar','M','Hussein',35621278678911,'M',011256378945,15000,'1995-11-12',NULL),
('Farouk','N','Samir',85694127867891,'M',011478463429,35000,'1995-12-1',NULL),
('Nada','A','Ahmed',15412786789112,'F',012457841478,25000,'1999-10-27',47127867891123),
('Mayada','A','Islam',47127867897845,'F',012478547847,15000,'2000-05-05',47127867891123),
('Tarek','A','Mansour',78447127867891,'M',015478956214,25000,'1996-10-11',NULL),
('Ziad','M','Mohamed',98744712786789,'M',011748932145,20000,'1997-08-01',NULL),
('Amira','O','Amr',15984712786789,'F',011478966987,18000,'1994-11-14',NULL),
('Karim','B','Omar',45547127867891,'M',010784574578,20000,'1996-10-4',NULL),
('Aballah','I','Amr',88835621278678,'M',010245396999,25000,'2000-09-08',47127867897845),
('Omar','A','Magdy',78447127867897,'M',010478487596,35000,'1990-01-08',NULL),
('Amer','O','Amr',47154712786789,'M',012582584784,35000,'1991-04-01',78447127867897),
('Amr','Z','Ahmed',78978447127867,'M',01147849652,45000,'1992-02-03',NULL),
('Shady','H','Hany',88547844712786,'M',01247846325,35000,'2000-01-19',47127867897845);



INSERT INTO LOGIN_EMPLOYEE (E_SSN,Username,Password)
VALUES
(12345678911234,'AhmedMoh123','7841545'),
(12345678911274,'Moaz516','147845'),
(72345678911234,'Mostafaa','478478'),
(12786789112341,'NaderYou','77j784'),
(47127867891123,'Salma576','Opo98as'),
(95212786789112,'Hesh01','784ssd8'),
(18345678914574,'Ali989','78awd2s1'),
(35621278678911,'Huss7','asasw2'),
(85694127867891,'FaroukN','Far748'),
(15412786789112,'Nadoush4','84NnNi'),
(47127867897845,'Maya7','qqwef7'),
(78447127867891,'Tark','poius77'),
(98744712786789,'ZiZo','ZiZo1'),
(15984712786789,'Mira1','0012_200'),
(45547127867891,'Karimm','OaqwAz7'),
(88835621278678,'Abdallah654','65431OplI4'),
(78447127867897,'OmaR','q237a2zA'),
(47154712786789,'AMm','iUiuuAp0'),
(78978447127867,'Amr92','w74aW'),
(88547844712786,'Chad','oiasA7');

INSERT INTO STATION (Station_Number,Station_Name,Manager_SSN,Manager_Start_Date,Location)
VALUES
(1,'Burg Al Arab',12345678911234,'2015-07-04','Alexandria'),
(2,'Port-Said',12786789112341,'2014-03-05','Port-Said'),
(3,'Aswan',47127867897845,'2014-03-01','Aswan'),
(4,'Luxor',98744712786789,'2013-06-11','Luxor'),
(5,'New Capital',12786789112341,'2014-02-01','New Capital'),
(6,'Mansoura',12786789112341,'2017-06-03','Dakahleya'),
(7,'Menya',78978447127867,'2018-09-14','Menya'),
(8,'Misr Station',15984712786789,'2015-07-04','Ramsis'),
(9,'Marsa Matrouh',85694127867891,'2016-05-01','Marsa Matrouh'),
(10,'Saloum',15412786789112,'2017-12-15','Saloum'),
(11,'Alyoub',45547127867891,'2018-09-14','Aluoubeya'),
(12,'Assiout',78447127867897,'2015-01-02','Assiout'),
(13,'Zagazig',88835621278678,'2014-07-08','Sharkeya'),
(14,'Fayoum',47127867897845,'2013-02-05','Fayoum'),
(15,'El Mahala Al Kobra',12345678911274,'2011-04-25','Gharbeya'),
(16,'Ismailia',12345678911234,'2012-04-05','Ismailia'),
(17,'Kafr El Sheikh',45547127867891,'2014-05-11','Kafr El Sheikh'),
(18,'Tanta',47154712786789,'2017-08-05','Gharbeya'),
(19,'Sohag',98744712786789,'2019-08-04','Sohag'),
(20,'Qena',18345678914574,'2012-05-04','Qena'),
(21,'Banha',95212786789112,'2017-09-08','Alyoubeya'),
(22,'Beni Suef',72345678911234,'2016-06-06','Beni Suef'),
(23,'Suez',85694127867891,'2015-01-04','Suez');

UPDATE EMPLOYEE SET Station_Number = 1 WHERE E_SSN = 12345678911234;
UPDATE EMPLOYEE SET Station_Number = 2 WHERE E_SSN = 12345678911274;
UPDATE EMPLOYEE SET Station_Number = 4 WHERE E_SSN = 72345678911234;
UPDATE EMPLOYEE SET Station_Number = 11 WHERE E_SSN = 12786789112341;
UPDATE EMPLOYEE SET Station_Number = 11 WHERE E_SSN = 47127867891123;
UPDATE EMPLOYEE SET Station_Number = 12 WHERE E_SSN = 95212786789112;
UPDATE EMPLOYEE SET Station_Number = 20 WHERE E_SSN = 18345678914574;
UPDATE EMPLOYEE SET Station_Number = 23 WHERE E_SSN = 35621278678911;
UPDATE EMPLOYEE SET Station_Number = 14 WHERE E_SSN = 85694127867891;
UPDATE EMPLOYEE SET Station_Number = 5 WHERE E_SSN = 15412786789112;
UPDATE EMPLOYEE SET Station_Number = 5 WHERE E_SSN = 47127867897845;
UPDATE EMPLOYEE SET Station_Number = 7 WHERE E_SSN = 78447127867891;
UPDATE EMPLOYEE SET Station_Number = 1 WHERE E_SSN = 98744712786789;
UPDATE EMPLOYEE SET Station_Number = 1 WHERE E_SSN = 15984712786789;
UPDATE EMPLOYEE SET Station_Number = 2 WHERE E_SSN = 45547127867891;
UPDATE EMPLOYEE SET Station_Number = 12 WHERE E_SSN = 88835621278678;
UPDATE EMPLOYEE SET Station_Number = 8 WHERE E_SSN = 78447127867897;
UPDATE EMPLOYEE SET Station_Number = 21 WHERE E_SSN = 47154712786789;
UPDATE EMPLOYEE SET Station_Number = 17 WHERE E_SSN = 78978447127867;
UPDATE EMPLOYEE SET Station_Number = 18 WHERE E_SSN = 88547844712786;



INSERT INTO SUPPLIER(Supplier_ID, Supplier_Address, Supplier_Name, Phone_Number)
VALUES
(1,'Beijing, China','CRRC',8611111111111),
(2,'Saint Petersburg, Russia','Kirov Plant', 70000000),
(3,'Munich, Germany','Siemens Mobility',4930901820),
(4,'Berlin, Germany','Bombardier Transportation',4980967820),
(5,'Brossard, Quebec, Canada','Railpower Technologies',16045555555),
(6,'Aarhus, Denmark','Frichs',4553232341),
(7,'Tampere, Finland','Lokomo',358501234567),
(8,'Levallois-Perret, France','Alstom',33109758351),
(9,'Crespin, France','ANF Industrie',33108410251),
(10,'Paris, France','Corpet-Louvet',33187902551),
(11,'Westphalia, Germany','Windhoff',4930875430),
(12,'Werdohl, Germany','Vossloh',4932315830),
(13,'Uttar Pradesh, India','Banaras Locomotive Works',912212345678),
(14,'Tamil Nadu, India','Golden Rock Railway Workshop',912875685678),
(15,'Mumbai, India','Tata Motors',912813290678),
(16,'Pistoia, Italy','Hitachi Rail Italy',393789438645),
(17,'Napoli, Italy','Trasporti',390823379111),
(18,'Tokyo, Japan','Mitsubishi Heavy Industries',810876986789),
(19,'Tokyo, Japan','Toshiba',810123456789),
(20,'Pennsylvania, United States','GE Transportation',15555551234);



INSERT INTO SPARE_PART(Part_Number,Price,Supplier_ID)
VALUES
(10,1000000,1),		--Engine
(11,5000,2),		--Engine Oil
(12,5000,3),		--Engine Valves
(13,50000,4),		--Engine Piston
(20,1000,5),		--Wheel
(21,2000,6),		--Brakes
(22,20000,7),		--Brake system
(23,1000,8),		--Brake Oil
(24,5000,9),		--Bearings
(30,20000,10),		--Small Gears
(31,25000,11),		--Medium Gears
(32,30000,12),		--Large Gears
(33,2000,13),		--Gears Oil
(34,50000,14),		--Transition Gears
(35,4000,15),		--Transition Gears Oil
(40,1000,16),		--Fuel Filter
(41,2500,17),		--Air Filter
(42,3500,18),		--Oil Filter
(50,10000,19),		--Compressor (For Air Conditioning)
(60,5000,20);		--Electrical Motors (For electronic doors)

INSERT INTO TRAIN (Train_Number,Economic_Class,Business_Class,Maintenance_Day)
VALUES
(1,50,20,'2021-05-05'),
(2,70,20,'2022-07-05'),
(3,60,10,'2023-08-15'),
(4,50,20,'2022-05-05'),
(5,50,10,'2024-01-04'),
(6,60,10,'2023-06-09'),
(7,50,10,'2021-09-04'),
(8,60,30,'2025-04-05'),
(9,50,30,'2025-05-05'),
(10,70,30,'2024-05-05'),
(11,60,20,'2023-07-05'),
(12,60,20,'2021-08-05'),
(13,50,10,'2022-05-04'),
(14,70,20,'2023-05-09'),
(15,50,10,'2024-05-14'),
(16,60,10,'2026-12-05'),
(17,50,10,'2025-05-05'),
(18,70,20,'2021-05-05'),
(19,50,20,'2023-07-08'),
(20,70,10,'2024-04-05');

INSERT INTO INVENTORY (Station_Number, Part_Number, Quantity)
VALUES
(1,10,3),
(1,11,50),
(1,12,40),
(1,13,20),
(1,20,15),
(1,21,30),
(1,22,15),
(1,23,40),
(1,24,100),
(1,30,25),
(1,31,30),
(1,32,35),
(1,33,20),
(1,34,20),
(1,40,30),
(1,41,10),
(1,42,20),
(1,50,5),
(1,60,30),

(2,10,3),
(2,11,50),
(2,12,40),
(2,13,20),
(2,20,15),
(2,21,30),
(2,22,15),
(2,23,40),
(2,24,100),
(2,30,25),
(2,31,30),
(2,32,35),
(2,33,20),
(2,34,20),
(2,40,30),
(2,41,10),
(2,42,20),
(2,50,5),
(2,60,30),

(3,10,3),
(3,11,50),
(3,12,40),
(3,13,20),
(3,20,15),
(3,21,30),
(3,22,15),
(3,23,40),
(3,33,20),
(3,34,20),
(3,40,30),
(3,41,10),
(3,42,20),
(3,50,5),
(3,60,30),

(4,10,3),
(4,11,50),
(4,12,40),
(4,13,20),
(4,20,15),
(4,21,30),
(4,22,15),
(4,23,40),
(4,24,100),
(4,40,30),
(4,41,10),
(4,42,20),
(4,50,5),
(4,60,30),

(5,10,3),
(5,11,50),
(5,12,40),
(5,13,20),
(5,20,15),
(5,21,30),
(5,33,20),
(5,34,20),
(5,40,30),
(5,41,10),
(5,42,20),
(5,50,5),
(5,60,30),

(6,10,3),
(6,23,40),
(6,24,100),
(6,30,25),
(6,31,30),
(6,32,35),
(6,33,20),
(6,34,20),
(6,40,30),
(6,41,10),
(6,42,20),
(6,50,5),
(6,60,30),

(7,10,3),
(7,32,35),
(7,33,20),
(7,34,20),
(7,40,30),
(7,41,10),
(7,42,20),
(7,50,5),
(7,60,30),

(8,10,3),
(8,11,50),
(8,12,40),
(8,13,20),
(8,20,15),
(8,21,30),
(8,22,15),
(8,23,40),
(8,24,100),
(8,30,25),
(8,31,30),
(8,32,35),
(8,33,20),
(8,34,20),
(8,50,5),
(8,60,30),

(9,10,3),
(9,11,50),
(9,12,40),
(9,13,20),
(9,20,15),
(9,21,30),
(9,22,15),
(9,23,40),
(9,24,100),
(9,30,25),
(9,31,30),
(9,32,35),

(10,10,3),
(10,11,50),
(10,12,40),
(10,13,20),
(10,20,15),
(10,21,30),
(10,22,15),
(10,23,40),
(10,24,100),
(10,30,25),
(10,31,30),
(10,32,35),
(10,33,20),
(10,34,20),
(10,40,30),
(10,41,10),
(10,42,20),
(10,50,5),
(10,60,30),

(11,10,3),
(11,11,50),
(11,32,35),
(11,42,20),
(11,50,5),
(11,60,30),

(12,10,3),
(12,11,50),
(12,12,40),
(12,13,20),
(12,20,15),
(12,21,30),
(12,33,20),
(12,34,20),
(12,40,30),
(12,41,10),
(12,42,20),
(12,50,5),
(12,60,30),

(13,10,3),
(13,11,50),
(13,12,40),
(13,13,20),


(14,20,15),
(14,21,30),
(14,22,15),
(14,23,40),


(15,24,100),
(15,30,25),
(15,31,30),
(15,32,35),


(16,32,35),
(16,33,20),
(16,34,20),
(16,40,30),

(17,41,10),
(17,42,20),
(17,50,5),
(17,60,30),

(18,20,15),
(18,21,30),
(18,22,15),
(18,23,40),
(18,24,100),
(18,30,25),
(18,31,30),
(18,32,35),
(18,33,20),

(19,20,15),
(19,21,30),
(19,22,15),
(19,23,40),
(19,24,100),

(20,30,25),
(20,31,30),
(20,32,35),
(20,33,20);

INSERT INTO TRIP(Trip_Number, Departure_Time, Arrival_Time, Economic_Ticket_Price,
Business_Ticket_Price, Business, Economic, Train_Number)
VALUES
(1,'6:00','8:30',20,70,30,70,1),
(2,'4:30','12:00',20,70,30,70,2),
(3,'10:00','12:00',20,70,30,70,3),
(4,'15:00','19:00',20,80,30,70,4),
(5,'20:00','22:00',20,80,30,70,5),

(6,'7:00','9:30',35,60,40,60,6),
(7,'11:00','13:45',35,60,40,60,7),
(8,'12:30','14:00',35,60,40,60,8),
(9,'14:30','17:00',35,60,40,60,9),
(10,'21:00','23:45',35,60,40,60,10),

(11,'2:30','5:00',40,55,45,55,11),
(12,'6:45','8:30',40,55,45,55,12),
(13,'16:00','18:45',40,55,45,55,13),
(14,'19:15','21:30',40,55,45,55,14),
(15,'22:00','23:45',40,55,45,55,15),

(16,'1:30','3:45',25,90,25,75,16),
(17,'4:15','6:00',25,90,25,75,17),
(18,'7:00','9:30',25,90,25,75,18),
(19,'10:30','12:00',25,90,25,75,19),
(20,'13:45','14:00',25,90,25,75,20);

-------------MOSTAFA------------------
INSERT INTO PASSENGER
VALUES
('Mostafa'	,'A','Ismail','M',12345678925400,32369115126,'1980-10-20'),
('Mohamed'	,'A','Abdelfattah','M',12345678925401,25010083156,'1981-11-21'),
('Ahmed'	,'A','Gali','M',12345678925402,69201892085,'1982-05-12'),
('Abdallah'	,'A','Radwan','M',12345678925403,97871229887,'1983-07-11'),
('Khaled'	,'A','Rashwan','M',12345678925404,31901272454,'1998-06-15'),
('Hussein'	,'A','Kamel','M',12345678925405,44276980139,'1998-05-02'),
('Mariam'	,'A','Moaz','F',12345678925406,33585806716,'1984-09-05'),
('Nada'		,'A','Nader','F',12345678925407,18759302464,'1985-02-07'),
('Habiba'	,'A','Chadi','F',12345678925408,23728221227,'1990-01-12'),
('Mennah'	,'A','Shamy','F',12345678925409,55621063128,'1991-06-17'),
('Aya'		,'A','Omar','F',12345678925410,05466721878,'1992-07-10'),
('Sarah'	,'A','Ibrahim','F',12345678925411,99090712225,'1993-04-02'),
('Salma'	,'A','Moataz','F',12345678925412,59654834347,'1994-03-08'),
('Farida'	,'A','Amr','F',12345678925413,83818727225,'1995-07-03'),
('Iman'		,'A','Salah','F',12345678925414,68592725297,'1996-06-25'),
('Somaia'	,'A','Essam','F',12345678925415,37905594828,'1998-06-13'),
('Wafaa'	,'A','Emam','F',12345678925416,58055980572,'1998-08-19'),
('Karim'	,'A','Salama','M',12345678925417,58107957800,'1985-12-06'),
('Abdelrahman','A','Shamy','M',12345678925418,84319998918,'1970-12-07'),
('Kamal'	,'A','Sabahi','M',12345678925419,80223512967,'1989-10-18');
-----------------------------------------------------------------------------------------
INSERT INTO LOGIN_PASSENGER
VALUES
(12345678925400,'Mostafa153','sda1234'),
(12345678925401,'Mohamed363','vsf1234'),
(12345678925402,'Ahmed12','ghj1234'),
(12345678925403,'Abdallah23','sdf1234'),
(12345678925404,'Khaled7','sge1234'),
(12345678925405,'Hussein3','hgj1234'),
(12345678925406,'Mariam2','fgh1234'),
(12345678925407,'Nada19','dsg1234'),
(12345678925408,'Habiba7','dfh1234'),
(12345678925409,'Mennah12','sgt1234'),
(12345678925410,'Aya123','sfg1234'),
(12345678925411,'Sarah653','fdh1234'),
(12345678925412,'Salma1','ghf1234'),
(12345678925413,'Farida23','sdg1234'),
(12345678925414,'Iman13','sdg1234'),
(12345678925415,'Somaia123','fgh1234'),
(12345678925416,'Wafaa165','sdg1234'),
(12345678925417,'Karim124','sdf1234'),
(12345678925418,'Abdelrahman_23','sdgh1234'),
(12345678925419,'Kamal64','qwe1234');

-------------MOSTAFA------------------



INSERT INTO BOOKINGS (P_SSN,Trip_Number,Trip_Date, [Type], [Status])--, Feedback_Rating, Feedback_Comment)
VALUES
(12345678925400	,1	,'2021-02-20', 'Economic','Upcoming'),
(12345678925400	,2	,'2021-04-30', 'Economic','Completed'),
(12345678925400	,3	,'2022-05-26', 'Business','Completed'),
(12345678925401	,1	,'2021-02-20', 'Economic','Completed'),
(12345678925402	,1	,'2021-06-13', 'Economic','Completed'),
(12345678925402	,6	,'2022-10-06', 'Business','Completed'),
(12345678925403	,5	,'2021-02-05', 'Economic','Completed'),
(12345678925406	,9	,'2021-07-20', 'Economic','Upcoming'),
(12345678925410	,19	,'2022-01-01', 'Business','Completed'),
(12345678925414	,1	,'2021-01-10', 'Economic','Completed'),
(12345678925404	,4	,'2022-10-06', 'Business','Upcoming'),
(12345678925413	,7	,'2021-12-20', 'Business','Completed'),
(12345678925403	,20	,'2021-03-12', 'Business','Upcoming'),
(12345678925415	,13	,'2022-06-01', 'Business','Upcoming'),
(12345678925417	,1	,'2021-05-20', 'Economic','Completed'),
(12345678925402	,14	,'2022-11-06', 'Business','Upcoming'),
(12345678925411	,12	,'2021-02-19', 'Economic','Completed'),
(12345678925406	,11	,'2022-09-25', 'Economic','Completed'),
(12345678925412	,18	,'2022-05-01', 'Business','Upcoming'),
(12345678925419	,3	,'2021-01-29', 'Economic','Upcoming');

INSERT INTO FROM_TO
VALUES
(1,2,9),
(2,1,8),
(3,5,7),
(4,6,4),
(5,3,5),
(6,4,6),
(7,7,2),
(8,8,12),
(9,2,15),
(10,1,14),
(11,1,17),
(12,2,12),
(13,15,13),
(14,4,5),
(15,6,7),
(16,9,8),
(17,8,7),
(18,2,6),
(19,14,3),
(20,3,1);



INSERT INTO REQUEST (E_SSN,Part_Number,Request_ID,Quantity,Status)
VALUES
(88835621278678,20,1,70,'Waiting'),
(47154712786789,21,2,40,'Accepted'),
(12345678911274,22,3,50,'Rejected'),
(88547844712786,24,4,22,'Rejected'),
(47154712786789,11,5,10,'Waiting'),
(18345678914574,12,6,30,'Waiting'),
(88547844712786,10,7,300,'Waiting'),
(88835621278678,35,8,10,'Accepted'),
(18345678914574,30,9,45,'Waiting'),
(47154712786789,20,10,100,'Accepted'),
(12345678911274,30,11,210,'Waiting'),
(47154712786789,42,12,215,'Rejected'),
(88547844712786,50,13,75,'Accepted'),
(18345678914574,60,14,45,'Waiting'),
(18345678914574,11,15,47,'Accepted'),
(47154712786789,12,16,50,'Waiting'),
(12345678911274,11,17,315,'Rejected'),
(12345678911274,35,18,60,'Accepted'),
(88835621278678,40,19,70,'Accepted'),
(88835621278678,50,20,100,'Rejected');





---------Procedures-----------------------------------------------


USE RAILWAY;
GO
CREATE PROCEDURE VIEW_EMPLOYEES
AS
BEGIN
SELECT * FROM Employee
END
GO

CREATE PROCEDURE VIEW_TRIPS
AS
BEGIN
SELECT * FROM TRIP
END
GO

CREATE PROCEDURE VIEW_TRAINS
AS
BEGIN
SELECT * FROM TRAIN
END
GO

CREATE PROCEDURE VIEW_STATIONS
AS
BEGIN
SELECT * FROM STATION
END
GO

CREATE PROCEDURE VIEW_SUPPLIERS
AS
BEGIN
SELECT * FROM SUPPLIER
END
GO

CREATE PROCEDURE VIEW_SPARE_PARTS
AS
BEGIN
SELECT * FROM SPARE_PART
END
GO

CREATE PROCEDURE CHANGE_TRAIN_MAINTENANCE_DATE @New_Date DATE,@Train_Number INT
AS
BEGIN
UPDATE TRAIN SET Maintenance_Day = @New_Date
WHERE Train_Number = @Train_Number
END
GO

CREATE PROCEDURE ADD_TRIP @Trip_Num INT , @Deprt_Time DATETIME, @Arr_Time DATETIME
, @Eco_Ticket_Price INT, @Buss_Ticket_Price INT, @Buss_No INT, @Eco_No INT
, @Train_No INT
AS
BEGIN
INSERT INTO TRIP (Trip_Number, Departure_Time, Arrival_Time, Economic_Ticket_Price
, Business_Ticket_Price, Business, Economic, Train_Number)
VALUES
(@Trip_Num,@Deprt_Time,@Arr_Time,@Eco_Ticket_Price, @Buss_Ticket_Price, @Buss_No,@Eco_No
,@Train_No)
END
GO

CREATE PROCEDURE REMOVE_TRIP @Trip_Num INT 
AS
BEGIN
DELETE FROM TRIP 
WHERE Trip_Number = @Trip_Num
END
GO



CREATE PROCEDURE VIEW_SPARE_PARTS_IN_STATION @Station_No INT
AS
BEGIN
SELECT Part_Number,Quantity
FROM INVENTORY
WHERE Station_Number = @Station_No
END
GO


CREATE PROCEDURE DEC_SPARE_PARTS @Station_No INT, @Part_No INT, @Amount INT
AS
BEGIN
UPDATE INVENTORY
SET Quantity = Quantity - @Amount
WHERE Station_Number = @Station_No AND Part_Number = @Part_No
END
GO


CREATE PROCEDURE ORDER_SPARE_PARTS @Part_No INT, @Amount INT, @SSN BIGINT ,@RequestID INT
AS
BEGIN
INSERT INTO REQUEST (Request_ID, E_SSN, Part_Number, Quantity, [Status] )
VALUES (@RequestID,@SSN,  @Part_No, @Amount, 'Waiting')
END
GO


CREATE PROCEDURE INSERT_EMPLOYEE @Fname VARCHAR(50), @Minit CHAR(1), @Lname VARCHAR(50), @SSN BIGINT,
								@Sex CHAR(1),@DOB DATE, @Phone_Number BIGINT, 
								@Manager_SSN BIGINT, @Salary INT,@Station_Number INT
AS
BEGIN
INSERT INTO EMPLOYEE 
VALUES (@Fname,@Minit,@Lname,@SSN,@Sex,@Phone_Number,@Salary,@DOB,@Manager_SSN,@Station_Number)
END
GO

CREATE PROCEDURE CHECK_EMPLOYEE_BY_SSN @SSN BIGINT
AS
BEGIN
SELECT COUNT(*)
FROM EMPLOYEE
WHERE E_SSN=@SSN
END
GO

CREATE PROCEDURE REMOVE_EMPLOYEE @SSN BIGINT
AS
BEGIN
DELETE FROM EMPLOYEE
WHERE E_SSN = @SSN
END
GO

CREATE PROCEDURE VIEW_REQUEST
AS
BEGIN
SELECT * FROM REQUEST
END
GO

CREATE PROCEDURE NO_TRAIN_TRIPS		@TrainNo INT
AS
BEGIN
SELECT COUNT(*) AS 'Count'
FROM TRIP
WHERE Train_Number = @TrainNo
END
GO


--------------moaz-----------

CREATE PROCEDURE INSERT_TRIP @PassengerId BIGINT, @TripNo INT, @TripDate DATE, @TypeB_E VARCHAR(8), @status VARCHAR(10)
AS
BEGIN
INSERT INTO BOOKINGS(P_SSN,Trip_Number,Trip_Date,Type,Status)
VALUES
(@PassengerId,@TripNo,@TripDate,@TypeB_E,@status)
END
GO

CREATE PROCEDURE DELETE_TRIP @PassengerId BIGINT, @TripNo INT, @TripDate DATE
AS 
BEGIN
DELETE FROM BOOKINGS 
WHERE P_SSN = @PassengerId AND Trip_Date = @TripDate AND Trip_Number = @TripNo AND Status = 'upcoming'
END
GO

CREATE PROCEDURE ViewPreviousTripinTable @PassengerId BIGINT
AS
BEGIN
SELECT B.P_SSN,B.Trip_Number,B.Trip_Date,S1.Station_Name, S2.Station_Name,B.Feedback_Rating,B.Feedback_Comment
FROM BOOKINGS AS B, FROM_TO AS F , STATION AS S1, STATION AS S2
WHERE B.P_SSN = @PassengerId AND Station_Number1 = S1.Station_Number AND Station_Number2 = S2.Station_Number AND B.Trip_Number = F.Trip_Number AND B.Status = 'Completed'
END
GO


CREATE PROCEDURE DisplayinTextBoxPreviousTrip @PassengerId BIGINT, @TripNo INT, @TripDate DATE
AS
BEGIN
SELECT * 
FROM BOOKINGS, TRIP, FROM_TO, STATION AS S1, STATION AS S2
WHERE P_SSN = @PassengerId AND BOOKINGS.Trip_Number = @TripNo AND BOOKINGS.Trip_Date = @TripDate AND Station_Number1 = S1.Station_Number AND Station_Number2 = S2.Station_Number AND BOOKINGS.Trip_Number = TRIP.Trip_Number AND TRIP.Trip_Number = FROM_TO.Trip_Number AND Status = 'Completed'
END
GO

CREATE PROCEDURE ViewAvailableTrip @PassengerId BIGINT, @currenttime TIME
AS
BEGIN
SELECT TRIP.Trip_Number, S1.Station_Name, S2.Station_Name, Departure_Time,Arrival_Time, Business, Business_Ticket_Price, Economic, Economic_Ticket_Price
FROM BOOKINGS, TRIP, FROM_TO, STATION AS S1, STATION AS S2
WHERE BOOKINGS.Trip_Number = TRIP.Trip_Number AND TRIP.Trip_Number = FROM_TO.Trip_Number  AND Station_Number1 = S1.Station_Number AND Station_Number2 = S2.Station_Number AND Departure_Time > @currenttime
END
GO

CREATE PROCEDURE ViewUpcomingTrip @PassengerId BIGINT
AS
BEGIN
SELECT *
FROM BOOKINGS, TRIP, FROM_TO, STATION AS S1, STATION AS S2
WHERE BOOKINGS.Trip_Number = TRIP.Trip_Number AND TRIP.Trip_Number = FROM_TO.Trip_Number AND Station_Number1 = S1.Station_Number AND Station_Number2 = S2.Station_Number AND P_SSN = @PassengerId AND Status = 'Upcoming'
END
GO

CREATE PROCEDURE ViewSpecificTrip @currenttime TIME, @stationName1 VARCHAR(50), @stationName2 VARCHAR(50) 
AS
BEGIN
SELECT TRIP.Trip_Number, S1.Station_Name, S2.Station_Name, Departure_Time,Arrival_Time, Business, Business_Ticket_Price, Economic, Economic_Ticket_Price
FROM BOOKINGS, TRIP, FROM_TO, STATION AS S1, STATION AS S2
WHERE BOOKINGS.Trip_Number = TRIP.Trip_Number AND TRIP.Trip_Number = FROM_TO.Trip_Number AND Station_Number1 = S1.Station_Number AND Station_Number2 = S2.Station_Number AND S1.Station_Name = @stationName1 AND S2.Station_Name = @stationName2 AND Departure_Time > @currenttime
END
GO

CREATE PROCEDURE INSERTFEEDBACK_W @Comment VARCHAR(100), @Rating INT, @PassengerId BIGINT, @TripNo INT,@TRIPDate DATE
AS
BEGIN
UPDATE BOOKINGS 
SET Feedback_Rating = @Rating, Feedback_Comment = @Comment
WHERE P_SSN = @PassengerId AND Trip_Number = @TripNo AND Trip_Date = Trip_Date
END
GO

CREATE PROCEDURE INSERTFEEDBACK_WO @Rating INT, @PassengerId BIGINT, @TripNo INT,@TRIPDate DATE
AS
BEGIN
UPDATE BOOKINGS 
SET Feedback_Rating = @Rating
WHERE P_SSN = @PassengerId AND Trip_Number = @TripNo AND Trip_Date = Trip_Date
END
GO

CREATE PROCEDURE ViewTrainInfo @TripNo INT
AS
BEGIN
SELECT * 
FROM TRIP
WHERE Trip_Number = @TripNo
END 
GO

CREATE PROCEDURE CHANGETRIPDATE @PassengerId BIGINT, @TripNo INT,@TRIPDate DATE, @TRIPDateNew DATE 
AS
BEGIN
UPDATE BOOKINGS
SET Trip_Date = @TRIPDateNew
WHERE  P_SSN = @PassengerId AND Trip_Number = @TripNo AND Trip_Date = Trip_Date
END
GO

CREATE PROCEDURE CHANGETRIPCLASS @PassengerId BIGINT,@TRIPClassNew VARCHAR(8)
AS
BEGIN
UPDATE BOOKINGS
SET Type = @TRIPClassNew
WHERE  P_SSN = @PassengerId AND Status = 'Upcoming'
END
GO

-------------moaz-------------


-------------Mostafa----------------------

CREATE PROCEDURE CHECK_LOGIN_PASSENGER @Username VARCHAR(20), @Password VARCHAR(20)
AS
BEGIN
SELECT COUNT(*) FROM LOGIN_PASSENGER WHERE Username = @Username AND Password=@Password
END
GO

CREATE PROCEDURE SIGNUP_PASSENGER @Fname varchar(20), @Minit char , @Lname varchar(20), @Phone_Number bigint,
@SSN bigint ,@gender char,@DOB Date,@Username VARCHAR(50), @Password Varchar(20)
AS
BEGIN
INSERT INTO PASSENGER 
VALUES
(@Fname,@Minit,@Lname,@gender,@SSN,@Phone_Number,@DOB)
INSERT INTO LOGIN_PASSENGER
VALUES
(@SSN,@Username,@Password)
END
GO

CREATE PROCEDURE CHECK_SSN_SIGN_UP_PASSENGER  @SSN bigint
AS
BEGIN
SELECT COUNT(*) FROM PASSENGER WHERE P_SSN=@SSN 
END
GO

CREATE PROCEDURE CHECK_USERNAME_SIGN_UP_PASSENGER @Username VARCHAR(50)
AS
BEGIN
SELECT COUNT(*) FROM LOGIN_PASSENGER WHERE Username=@Username 
END
GO



CREATE PROCEDURE CHECK_LOGIN_EMPLOYEE @Username VARCHAR(20), @Password VARCHAR(20)
AS
BEGIN
SELECT COUNT(*) FROM LOGIN_EMPLOYEE WHERE Username = @Username AND Password=@Password
END
GO


CREATE PROCEDURE GET_EMPLOYEE_DATA @Username VARCHAR(50)
AS
BEGIN
SELECT E.E_SSN,E.Manager_SSN,E.Station_Number FROM EMPLOYEE AS E,LOGIN_EMPLOYEE AS L WHERE L.Username=@Username AND L.E_SSN=E.E_SSN
END
GO

CREATE PROCEDURE GET_PASSENGER_SSN @Username VARCHAR(50)
AS
BEGIN
SELECT P_SSN FROM LOGIN_PASSENGER WHERE Username=@Username
END
GO

--------------Mostafa--------------------



