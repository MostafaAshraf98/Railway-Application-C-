﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Railway_Management_System
{
    public partial class CrystalReport : Form
    {
        public CrystalReport()
        {
            InitializeComponent();
        }

        private void CrystalReport_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'DataSet1.BOOKINGS' table. You can move, or remove it, as needed.
            this.BOOKINGSTableAdapter.Fill(this.DataSet1.BOOKINGS);

            this.reportViewer1.RefreshReport();
            this.reportViewer2.RefreshReport();
        }
    }
}
