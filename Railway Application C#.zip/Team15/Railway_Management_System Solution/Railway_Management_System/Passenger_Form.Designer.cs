﻿namespace Railway_Management_System
{
    partial class Passenger_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CancelTripsButton = new System.Windows.Forms.Button();
            this.Change_Trips_Button = new System.Windows.Forms.Button();
            this.Previous_Trips = new System.Windows.Forms.Button();
            this.Upcoming_Trips = new System.Windows.Forms.Button();
            this.Book_Trips = new System.Windows.Forms.Button();
            this.Book_TripsGroupBox = new System.Windows.Forms.GroupBox();
            this.TypeGroupBox = new System.Windows.Forms.GroupBox();
            this.Booktrip_TripDate = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.Booktrip_SeatsLeftTextBox = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Booktrip_Economicbutton = new System.Windows.Forms.Button();
            this.Booktrip_Businessbutton = new System.Windows.Forms.Button();
            this.Booktrip_BookButton = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.Booktrip_ArrivaltextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Booktrip_DeparturetextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Booktrip_PriceTextBox = new System.Windows.Forms.TextBox();
            this.Booktrip_Show_All_Available_Tripsbutton = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Booktrip_to = new System.Windows.Forms.ComboBox();
            this.Booktrip_From = new System.Windows.Forms.ComboBox();
            this.Booktrip_TripNoTextBox = new System.Windows.Forms.TextBox();
            this.Booktrip_SearchButton = new System.Windows.Forms.Button();
            this.scheduleDataGridView = new System.Windows.Forms.DataGridView();
            this.CancelBookgroupBox = new System.Windows.Forms.GroupBox();
            this.Cancel_TripDatetextBox = new System.Windows.Forms.DateTimePicker();
            this.Cancel_TypetextBox = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.Cancel_ContinueButton = new System.Windows.Forms.Button();
            this.Cancel_ArrivaltextBox = new System.Windows.Forms.TextBox();
            this.Cancel_CancelButton = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.Cancel_DeparturetextBox = new System.Windows.Forms.TextBox();
            this.Cancel_FromtextBox = new System.Windows.Forms.TextBox();
            this.Cancel_TotextBox = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.Cancel_PricetextBox = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.Cancel_TripNotextBox = new System.Windows.Forms.TextBox();
            this.UpdateTripGroupBox = new System.Windows.Forms.GroupBox();
            this.UPdate_Date = new System.Windows.Forms.DateTimePicker();
            this.Type_Update = new System.Windows.Forms.GroupBox();
            this.Economic_Updatebutton = new System.Windows.Forms.Button();
            this.Business_Updatebutton = new System.Windows.Forms.Button();
            this.UpdateButton = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.Update__arrival = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.Update_departure = new System.Windows.Forms.TextBox();
            this.Update_from = new System.Windows.Forms.TextBox();
            this.Update_to = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.Update_price = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.Update_tripNo = new System.Windows.Forms.TextBox();
            this.Upcoming_groupBox = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.Upcoming_Train_No_TextBox = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.BusinessgroupBox = new System.Windows.Forms.GroupBox();
            this.Upcoming_BusinessPrice = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.Upcoming_businessSeatsLeft = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.EconomicgroupBox = new System.Windows.Forms.GroupBox();
            this.Upcoming_EconomicPrice = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.Upcoming_EconomicSeatsLeft = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.UpdateTrainInfoButton = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.Upcoming_Tripdate = new System.Windows.Forms.DateTimePicker();
            this.Upcoming_Type = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.Upcoming_Arrival = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.Upcoming_Departure = new System.Windows.Forms.TextBox();
            this.Upcoming_From = new System.Windows.Forms.TextBox();
            this.Upcoming_To = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.Upcoming_price = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.Upcoming_TripNo = new System.Windows.Forms.TextBox();
            this.PreviousgroupBox = new System.Windows.Forms.GroupBox();
            this.Previous_tripDate = new System.Windows.Forms.DateTimePicker();
            this.FeedbackGroupBox = new System.Windows.Forms.GroupBox();
            this.label25 = new System.Windows.Forms.Label();
            this.RatingCombo = new System.Windows.Forms.ComboBox();
            this.RatingLabel = new System.Windows.Forms.Label();
            this.CommentTextBox = new System.Windows.Forms.TextBox();
            this.AddFeedbackButton = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Previous_Type = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.Previous_Arrival = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.Previous_Departure = new System.Windows.Forms.TextBox();
            this.Previous_From_Textbox = new System.Windows.Forms.TextBox();
            this.Previous_to_Textbox = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.Previous_Price = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.Previous_tripNo = new System.Windows.Forms.TextBox();
            this.Book_TripsGroupBox.SuspendLayout();
            this.TypeGroupBox.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scheduleDataGridView)).BeginInit();
            this.CancelBookgroupBox.SuspendLayout();
            this.UpdateTripGroupBox.SuspendLayout();
            this.Type_Update.SuspendLayout();
            this.Upcoming_groupBox.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.BusinessgroupBox.SuspendLayout();
            this.EconomicgroupBox.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.PreviousgroupBox.SuspendLayout();
            this.FeedbackGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // CancelTripsButton
            // 
            this.CancelTripsButton.BackColor = System.Drawing.Color.Navy;
            this.CancelTripsButton.FlatAppearance.BorderSize = 0;
            this.CancelTripsButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.CancelTripsButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CancelTripsButton.ForeColor = System.Drawing.Color.White;
            this.CancelTripsButton.Location = new System.Drawing.Point(0, 166);
            this.CancelTripsButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.CancelTripsButton.Name = "CancelTripsButton";
            this.CancelTripsButton.Size = new System.Drawing.Size(112, 91);
            this.CancelTripsButton.TabIndex = 25;
            this.CancelTripsButton.Text = "Cancel Trip";
            this.CancelTripsButton.UseVisualStyleBackColor = false;
            this.CancelTripsButton.Click += new System.EventHandler(this.CancelTripsButton_Click);
            // 
            // Change_Trips_Button
            // 
            this.Change_Trips_Button.BackColor = System.Drawing.Color.Navy;
            this.Change_Trips_Button.FlatAppearance.BorderSize = 0;
            this.Change_Trips_Button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.Change_Trips_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Change_Trips_Button.ForeColor = System.Drawing.Color.White;
            this.Change_Trips_Button.Location = new System.Drawing.Point(0, 80);
            this.Change_Trips_Button.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Change_Trips_Button.Name = "Change_Trips_Button";
            this.Change_Trips_Button.Size = new System.Drawing.Size(112, 91);
            this.Change_Trips_Button.TabIndex = 24;
            this.Change_Trips_Button.Text = "Change Trip";
            this.Change_Trips_Button.UseVisualStyleBackColor = false;
            this.Change_Trips_Button.Click += new System.EventHandler(this.Change_Trips_Button_Click_1);
            // 
            // Previous_Trips
            // 
            this.Previous_Trips.BackColor = System.Drawing.Color.Navy;
            this.Previous_Trips.FlatAppearance.BorderSize = 0;
            this.Previous_Trips.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.Previous_Trips.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Previous_Trips.ForeColor = System.Drawing.Color.White;
            this.Previous_Trips.Location = new System.Drawing.Point(0, 341);
            this.Previous_Trips.Name = "Previous_Trips";
            this.Previous_Trips.Size = new System.Drawing.Size(112, 91);
            this.Previous_Trips.TabIndex = 23;
            this.Previous_Trips.Text = "Previous Trips";
            this.Previous_Trips.UseVisualStyleBackColor = false;
            this.Previous_Trips.Click += new System.EventHandler(this.Previous_Trips_Click_1);
            // 
            // Upcoming_Trips
            // 
            this.Upcoming_Trips.BackColor = System.Drawing.Color.Navy;
            this.Upcoming_Trips.FlatAppearance.BorderSize = 0;
            this.Upcoming_Trips.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.Upcoming_Trips.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Upcoming_Trips.ForeColor = System.Drawing.Color.White;
            this.Upcoming_Trips.Location = new System.Drawing.Point(0, 255);
            this.Upcoming_Trips.Name = "Upcoming_Trips";
            this.Upcoming_Trips.Size = new System.Drawing.Size(112, 91);
            this.Upcoming_Trips.TabIndex = 22;
            this.Upcoming_Trips.Text = "Upcoming Trip";
            this.Upcoming_Trips.UseVisualStyleBackColor = false;
            this.Upcoming_Trips.Click += new System.EventHandler(this.Upcoming_Trips_Click_1);
            // 
            // Book_Trips
            // 
            this.Book_Trips.BackColor = System.Drawing.Color.Navy;
            this.Book_Trips.FlatAppearance.BorderSize = 0;
            this.Book_Trips.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.Book_Trips.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Book_Trips.ForeColor = System.Drawing.Color.White;
            this.Book_Trips.Location = new System.Drawing.Point(0, -1);
            this.Book_Trips.Name = "Book_Trips";
            this.Book_Trips.Size = new System.Drawing.Size(112, 91);
            this.Book_Trips.TabIndex = 21;
            this.Book_Trips.Text = "Book Trip";
            this.Book_Trips.UseVisualStyleBackColor = false;
            this.Book_Trips.Click += new System.EventHandler(this.Book_Trips_Click);
            // 
            // Book_TripsGroupBox
            // 
            this.Book_TripsGroupBox.Controls.Add(this.TypeGroupBox);
            this.Book_TripsGroupBox.Controls.Add(this.scheduleDataGridView);
            this.Book_TripsGroupBox.Location = new System.Drawing.Point(123, 10);
            this.Book_TripsGroupBox.Name = "Book_TripsGroupBox";
            this.Book_TripsGroupBox.Size = new System.Drawing.Size(648, 422);
            this.Book_TripsGroupBox.TabIndex = 26;
            this.Book_TripsGroupBox.TabStop = false;
            this.Book_TripsGroupBox.Text = "Trips";
            this.Book_TripsGroupBox.Visible = false;
            // 
            // TypeGroupBox
            // 
            this.TypeGroupBox.Controls.Add(this.Booktrip_TripDate);
            this.TypeGroupBox.Controls.Add(this.label6);
            this.TypeGroupBox.Controls.Add(this.Booktrip_SeatsLeftTextBox);
            this.TypeGroupBox.Controls.Add(this.groupBox1);
            this.TypeGroupBox.Controls.Add(this.Booktrip_BookButton);
            this.TypeGroupBox.Controls.Add(this.label8);
            this.TypeGroupBox.Controls.Add(this.Booktrip_ArrivaltextBox);
            this.TypeGroupBox.Controls.Add(this.label7);
            this.TypeGroupBox.Controls.Add(this.Booktrip_DeparturetextBox);
            this.TypeGroupBox.Controls.Add(this.label2);
            this.TypeGroupBox.Controls.Add(this.Booktrip_PriceTextBox);
            this.TypeGroupBox.Controls.Add(this.Booktrip_Show_All_Available_Tripsbutton);
            this.TypeGroupBox.Controls.Add(this.label5);
            this.TypeGroupBox.Controls.Add(this.label4);
            this.TypeGroupBox.Controls.Add(this.label3);
            this.TypeGroupBox.Controls.Add(this.label1);
            this.TypeGroupBox.Controls.Add(this.Booktrip_to);
            this.TypeGroupBox.Controls.Add(this.Booktrip_From);
            this.TypeGroupBox.Controls.Add(this.Booktrip_TripNoTextBox);
            this.TypeGroupBox.Controls.Add(this.Booktrip_SearchButton);
            this.TypeGroupBox.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.TypeGroupBox.Location = new System.Drawing.Point(5, 193);
            this.TypeGroupBox.Name = "TypeGroupBox";
            this.TypeGroupBox.Size = new System.Drawing.Size(639, 207);
            this.TypeGroupBox.TabIndex = 10;
            this.TypeGroupBox.TabStop = false;
            this.TypeGroupBox.Text = "Booking";
            // 
            // Booktrip_TripDate
            // 
            this.Booktrip_TripDate.Location = new System.Drawing.Point(60, 70);
            this.Booktrip_TripDate.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Booktrip_TripDate.Name = "Booktrip_TripDate";
            this.Booktrip_TripDate.Size = new System.Drawing.Size(151, 20);
            this.Booktrip_TripDate.TabIndex = 35;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(179, 106);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 13);
            this.label6.TabIndex = 34;
            this.label6.Text = "Seats Left";
            // 
            // Booktrip_SeatsLeftTextBox
            // 
            this.Booktrip_SeatsLeftTextBox.Location = new System.Drawing.Point(236, 102);
            this.Booktrip_SeatsLeftTextBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Booktrip_SeatsLeftTextBox.Name = "Booktrip_SeatsLeftTextBox";
            this.Booktrip_SeatsLeftTextBox.ReadOnly = true;
            this.Booktrip_SeatsLeftTextBox.Size = new System.Drawing.Size(76, 20);
            this.Booktrip_SeatsLeftTextBox.TabIndex = 33;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Booktrip_Economicbutton);
            this.groupBox1.Controls.Add(this.Booktrip_Businessbutton);
            this.groupBox1.Location = new System.Drawing.Point(305, 14);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(150, 74);
            this.groupBox1.TabIndex = 32;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Type(Bussiness/Economic)";
            // 
            // Booktrip_Economicbutton
            // 
            this.Booktrip_Economicbutton.BackColor = System.Drawing.Color.CadetBlue;
            this.Booktrip_Economicbutton.FlatAppearance.BorderSize = 0;
            this.Booktrip_Economicbutton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.Booktrip_Economicbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Booktrip_Economicbutton.ForeColor = System.Drawing.Color.White;
            this.Booktrip_Economicbutton.Location = new System.Drawing.Point(78, 29);
            this.Booktrip_Economicbutton.Name = "Booktrip_Economicbutton";
            this.Booktrip_Economicbutton.Size = new System.Drawing.Size(64, 37);
            this.Booktrip_Economicbutton.TabIndex = 31;
            this.Booktrip_Economicbutton.Text = "Economic";
            this.Booktrip_Economicbutton.UseVisualStyleBackColor = false;
            this.Booktrip_Economicbutton.Click += new System.EventHandler(this.Booktrip_Economicbutton_Click);
            // 
            // Booktrip_Businessbutton
            // 
            this.Booktrip_Businessbutton.BackColor = System.Drawing.Color.CadetBlue;
            this.Booktrip_Businessbutton.FlatAppearance.BorderSize = 0;
            this.Booktrip_Businessbutton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.Booktrip_Businessbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Booktrip_Businessbutton.ForeColor = System.Drawing.Color.White;
            this.Booktrip_Businessbutton.Location = new System.Drawing.Point(8, 29);
            this.Booktrip_Businessbutton.Name = "Booktrip_Businessbutton";
            this.Booktrip_Businessbutton.Size = new System.Drawing.Size(64, 37);
            this.Booktrip_Businessbutton.TabIndex = 30;
            this.Booktrip_Businessbutton.Text = "Business";
            this.Booktrip_Businessbutton.UseVisualStyleBackColor = false;
            this.Booktrip_Businessbutton.Click += new System.EventHandler(this.Booktrip_Businessbutton_Click);
            // 
            // Booktrip_BookButton
            // 
            this.Booktrip_BookButton.BackColor = System.Drawing.Color.Navy;
            this.Booktrip_BookButton.FlatAppearance.BorderSize = 0;
            this.Booktrip_BookButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.Booktrip_BookButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Booktrip_BookButton.ForeColor = System.Drawing.Color.White;
            this.Booktrip_BookButton.Location = new System.Drawing.Point(493, 154);
            this.Booktrip_BookButton.Name = "Booktrip_BookButton";
            this.Booktrip_BookButton.Size = new System.Drawing.Size(134, 37);
            this.Booktrip_BookButton.TabIndex = 29;
            this.Booktrip_BookButton.Text = "Book";
            this.Booktrip_BookButton.UseVisualStyleBackColor = false;
            this.Booktrip_BookButton.Click += new System.EventHandler(this.Booktrip_BookButton_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(171, 144);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 13);
            this.label8.TabIndex = 28;
            this.label8.Text = "Arrival time";
            // 
            // Booktrip_ArrivaltextBox
            // 
            this.Booktrip_ArrivaltextBox.Location = new System.Drawing.Point(236, 140);
            this.Booktrip_ArrivaltextBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Booktrip_ArrivaltextBox.Name = "Booktrip_ArrivaltextBox";
            this.Booktrip_ArrivaltextBox.ReadOnly = true;
            this.Booktrip_ArrivaltextBox.Size = new System.Drawing.Size(76, 20);
            this.Booktrip_ArrivaltextBox.TabIndex = 27;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 144);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(76, 13);
            this.label7.TabIndex = 26;
            this.label7.Text = "Departure time";
            // 
            // Booktrip_DeparturetextBox
            // 
            this.Booktrip_DeparturetextBox.Location = new System.Drawing.Point(84, 140);
            this.Booktrip_DeparturetextBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Booktrip_DeparturetextBox.Name = "Booktrip_DeparturetextBox";
            this.Booktrip_DeparturetextBox.ReadOnly = true;
            this.Booktrip_DeparturetextBox.Size = new System.Drawing.Size(76, 20);
            this.Booktrip_DeparturetextBox.TabIndex = 25;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(344, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 24;
            this.label2.Text = "Price";
            // 
            // Booktrip_PriceTextBox
            // 
            this.Booktrip_PriceTextBox.Location = new System.Drawing.Point(379, 102);
            this.Booktrip_PriceTextBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Booktrip_PriceTextBox.Name = "Booktrip_PriceTextBox";
            this.Booktrip_PriceTextBox.ReadOnly = true;
            this.Booktrip_PriceTextBox.Size = new System.Drawing.Size(76, 20);
            this.Booktrip_PriceTextBox.TabIndex = 23;
            // 
            // Booktrip_Show_All_Available_Tripsbutton
            // 
            this.Booktrip_Show_All_Available_Tripsbutton.BackColor = System.Drawing.Color.Navy;
            this.Booktrip_Show_All_Available_Tripsbutton.FlatAppearance.BorderSize = 0;
            this.Booktrip_Show_All_Available_Tripsbutton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.Booktrip_Show_All_Available_Tripsbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Booktrip_Show_All_Available_Tripsbutton.ForeColor = System.Drawing.Color.White;
            this.Booktrip_Show_All_Available_Tripsbutton.Location = new System.Drawing.Point(493, 93);
            this.Booktrip_Show_All_Available_Tripsbutton.Name = "Booktrip_Show_All_Available_Tripsbutton";
            this.Booktrip_Show_All_Available_Tripsbutton.Size = new System.Drawing.Size(134, 37);
            this.Booktrip_Show_All_Available_Tripsbutton.TabIndex = 22;
            this.Booktrip_Show_All_Available_Tripsbutton.Text = "Show All Available Trips";
            this.Booktrip_Show_All_Available_Tripsbutton.UseVisualStyleBackColor = false;
            this.Booktrip_Show_All_Available_Tripsbutton.Click += new System.EventHandler(this.Booktrip_Show_All_Available_Tripsbutton_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 74);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 13);
            this.label5.TabIndex = 19;
            this.label5.Text = "Trip Date";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 13);
            this.label4.TabIndex = 18;
            this.label4.Text = "Trip Number";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(154, 40);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "To:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 16;
            this.label1.Text = "From:";
            // 
            // Booktrip_to
            // 
            this.Booktrip_to.FormattingEnabled = true;
            this.Booktrip_to.Location = new System.Drawing.Point(177, 36);
            this.Booktrip_to.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Booktrip_to.Name = "Booktrip_to";
            this.Booktrip_to.Size = new System.Drawing.Size(92, 21);
            this.Booktrip_to.TabIndex = 15;
            // 
            // Booktrip_From
            // 
            this.Booktrip_From.FormattingEnabled = true;
            this.Booktrip_From.Location = new System.Drawing.Point(58, 36);
            this.Booktrip_From.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Booktrip_From.Name = "Booktrip_From";
            this.Booktrip_From.Size = new System.Drawing.Size(92, 21);
            this.Booktrip_From.TabIndex = 14;
            // 
            // Booktrip_TripNoTextBox
            // 
            this.Booktrip_TripNoTextBox.Location = new System.Drawing.Point(84, 102);
            this.Booktrip_TripNoTextBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Booktrip_TripNoTextBox.Name = "Booktrip_TripNoTextBox";
            this.Booktrip_TripNoTextBox.ReadOnly = true;
            this.Booktrip_TripNoTextBox.Size = new System.Drawing.Size(76, 20);
            this.Booktrip_TripNoTextBox.TabIndex = 12;
            // 
            // Booktrip_SearchButton
            // 
            this.Booktrip_SearchButton.BackColor = System.Drawing.Color.Navy;
            this.Booktrip_SearchButton.FlatAppearance.BorderSize = 0;
            this.Booktrip_SearchButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.Booktrip_SearchButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Booktrip_SearchButton.ForeColor = System.Drawing.Color.White;
            this.Booktrip_SearchButton.Location = new System.Drawing.Point(493, 26);
            this.Booktrip_SearchButton.Name = "Booktrip_SearchButton";
            this.Booktrip_SearchButton.Size = new System.Drawing.Size(134, 37);
            this.Booktrip_SearchButton.TabIndex = 9;
            this.Booktrip_SearchButton.Text = "Search";
            this.Booktrip_SearchButton.UseVisualStyleBackColor = false;
            this.Booktrip_SearchButton.Click += new System.EventHandler(this.Booktrip_SearchButton_Click);
            // 
            // scheduleDataGridView
            // 
            this.scheduleDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.scheduleDataGridView.Location = new System.Drawing.Point(5, 19);
            this.scheduleDataGridView.Name = "scheduleDataGridView";
            this.scheduleDataGridView.RowHeadersWidth = 51;
            this.scheduleDataGridView.Size = new System.Drawing.Size(640, 163);
            this.scheduleDataGridView.TabIndex = 7;
            this.scheduleDataGridView.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.BookMouseClick);
            // 
            // CancelBookgroupBox
            // 
            this.CancelBookgroupBox.Controls.Add(this.Cancel_TripDatetextBox);
            this.CancelBookgroupBox.Controls.Add(this.Cancel_TypetextBox);
            this.CancelBookgroupBox.Controls.Add(this.label16);
            this.CancelBookgroupBox.Controls.Add(this.Cancel_ContinueButton);
            this.CancelBookgroupBox.Controls.Add(this.Cancel_ArrivaltextBox);
            this.CancelBookgroupBox.Controls.Add(this.Cancel_CancelButton);
            this.CancelBookgroupBox.Controls.Add(this.label17);
            this.CancelBookgroupBox.Controls.Add(this.label18);
            this.CancelBookgroupBox.Controls.Add(this.Cancel_DeparturetextBox);
            this.CancelBookgroupBox.Controls.Add(this.Cancel_FromtextBox);
            this.CancelBookgroupBox.Controls.Add(this.Cancel_TotextBox);
            this.CancelBookgroupBox.Controls.Add(this.label19);
            this.CancelBookgroupBox.Controls.Add(this.Cancel_PricetextBox);
            this.CancelBookgroupBox.Controls.Add(this.label20);
            this.CancelBookgroupBox.Controls.Add(this.label21);
            this.CancelBookgroupBox.Controls.Add(this.label22);
            this.CancelBookgroupBox.Controls.Add(this.label23);
            this.CancelBookgroupBox.Controls.Add(this.label24);
            this.CancelBookgroupBox.Controls.Add(this.Cancel_TripNotextBox);
            this.CancelBookgroupBox.Location = new System.Drawing.Point(118, 10);
            this.CancelBookgroupBox.Name = "CancelBookgroupBox";
            this.CancelBookgroupBox.Size = new System.Drawing.Size(646, 426);
            this.CancelBookgroupBox.TabIndex = 55;
            this.CancelBookgroupBox.TabStop = false;
            this.CancelBookgroupBox.Text = "Cancel Booking";
            // 
            // Cancel_TripDatetextBox
            // 
            this.Cancel_TripDatetextBox.Enabled = false;
            this.Cancel_TripDatetextBox.Location = new System.Drawing.Point(412, 94);
            this.Cancel_TripDatetextBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Cancel_TripDatetextBox.Name = "Cancel_TripDatetextBox";
            this.Cancel_TripDatetextBox.Size = new System.Drawing.Size(151, 20);
            this.Cancel_TripDatetextBox.TabIndex = 53;
            this.Cancel_TripDatetextBox.UseWaitCursor = true;
            // 
            // Cancel_TypetextBox
            // 
            this.Cancel_TypetextBox.Location = new System.Drawing.Point(412, 39);
            this.Cancel_TypetextBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Cancel_TypetextBox.Name = "Cancel_TypetextBox";
            this.Cancel_TypetextBox.ReadOnly = true;
            this.Cancel_TypetextBox.Size = new System.Drawing.Size(76, 20);
            this.Cancel_TypetextBox.TabIndex = 52;
            this.Cancel_TypetextBox.UseWaitCursor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(271, 157);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(58, 13);
            this.label16.TabIndex = 51;
            this.label16.Text = "Arrival time";
            this.label16.UseWaitCursor = true;
            // 
            // Cancel_ContinueButton
            // 
            this.Cancel_ContinueButton.BackColor = System.Drawing.Color.Navy;
            this.Cancel_ContinueButton.FlatAppearance.BorderSize = 0;
            this.Cancel_ContinueButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.Cancel_ContinueButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Cancel_ContinueButton.ForeColor = System.Drawing.Color.White;
            this.Cancel_ContinueButton.Location = new System.Drawing.Point(190, 258);
            this.Cancel_ContinueButton.Name = "Cancel_ContinueButton";
            this.Cancel_ContinueButton.Size = new System.Drawing.Size(96, 38);
            this.Cancel_ContinueButton.TabIndex = 11;
            this.Cancel_ContinueButton.Text = "Continue";
            this.Cancel_ContinueButton.UseVisualStyleBackColor = false;
            this.Cancel_ContinueButton.UseWaitCursor = true;
            this.Cancel_ContinueButton.Click += new System.EventHandler(this.Cancel_ContinueButton_Click);
            // 
            // Cancel_ArrivaltextBox
            // 
            this.Cancel_ArrivaltextBox.Location = new System.Drawing.Point(334, 153);
            this.Cancel_ArrivaltextBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Cancel_ArrivaltextBox.Name = "Cancel_ArrivaltextBox";
            this.Cancel_ArrivaltextBox.ReadOnly = true;
            this.Cancel_ArrivaltextBox.Size = new System.Drawing.Size(76, 20);
            this.Cancel_ArrivaltextBox.TabIndex = 50;
            this.Cancel_ArrivaltextBox.UseWaitCursor = true;
            // 
            // Cancel_CancelButton
            // 
            this.Cancel_CancelButton.BackColor = System.Drawing.Color.Navy;
            this.Cancel_CancelButton.FlatAppearance.BorderSize = 0;
            this.Cancel_CancelButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.Cancel_CancelButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Cancel_CancelButton.ForeColor = System.Drawing.Color.White;
            this.Cancel_CancelButton.Location = new System.Drawing.Point(324, 258);
            this.Cancel_CancelButton.Name = "Cancel_CancelButton";
            this.Cancel_CancelButton.Size = new System.Drawing.Size(102, 38);
            this.Cancel_CancelButton.TabIndex = 10;
            this.Cancel_CancelButton.Text = "Cancel";
            this.Cancel_CancelButton.UseVisualStyleBackColor = false;
            this.Cancel_CancelButton.UseWaitCursor = true;
            this.Cancel_CancelButton.Click += new System.EventHandler(this.Cancel_CancelButton_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(103, 154);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(76, 13);
            this.label17.TabIndex = 49;
            this.label17.Text = "Departure time";
            this.label17.UseWaitCursor = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(200, 210);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(209, 13);
            this.label18.TabIndex = 0;
            this.label18.Text = "Do you want to cancel your upcoming trip?";
            this.label18.UseWaitCursor = true;
            // 
            // Cancel_DeparturetextBox
            // 
            this.Cancel_DeparturetextBox.Location = new System.Drawing.Point(184, 154);
            this.Cancel_DeparturetextBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Cancel_DeparturetextBox.Name = "Cancel_DeparturetextBox";
            this.Cancel_DeparturetextBox.ReadOnly = true;
            this.Cancel_DeparturetextBox.Size = new System.Drawing.Size(76, 20);
            this.Cancel_DeparturetextBox.TabIndex = 48;
            this.Cancel_DeparturetextBox.UseWaitCursor = true;
            // 
            // Cancel_FromtextBox
            // 
            this.Cancel_FromtextBox.Location = new System.Drawing.Point(148, 44);
            this.Cancel_FromtextBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Cancel_FromtextBox.Name = "Cancel_FromtextBox";
            this.Cancel_FromtextBox.ReadOnly = true;
            this.Cancel_FromtextBox.Size = new System.Drawing.Size(76, 20);
            this.Cancel_FromtextBox.TabIndex = 47;
            this.Cancel_FromtextBox.UseWaitCursor = true;
            // 
            // Cancel_TotextBox
            // 
            this.Cancel_TotextBox.Location = new System.Drawing.Point(278, 41);
            this.Cancel_TotextBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Cancel_TotextBox.Name = "Cancel_TotextBox";
            this.Cancel_TotextBox.ReadOnly = true;
            this.Cancel_TotextBox.Size = new System.Drawing.Size(76, 20);
            this.Cancel_TotextBox.TabIndex = 46;
            this.Cancel_TotextBox.UseWaitCursor = true;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(243, 102);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(31, 13);
            this.label19.TabIndex = 45;
            this.label19.Text = "Price";
            this.label19.UseWaitCursor = true;
            // 
            // Cancel_PricetextBox
            // 
            this.Cancel_PricetextBox.Location = new System.Drawing.Point(278, 98);
            this.Cancel_PricetextBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Cancel_PricetextBox.Name = "Cancel_PricetextBox";
            this.Cancel_PricetextBox.ReadOnly = true;
            this.Cancel_PricetextBox.Size = new System.Drawing.Size(76, 20);
            this.Cancel_PricetextBox.TabIndex = 44;
            this.Cancel_PricetextBox.UseWaitCursor = true;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(370, 41);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(31, 13);
            this.label20.TabIndex = 43;
            this.label20.Text = "Type";
            this.label20.UseWaitCursor = true;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(359, 98);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(51, 13);
            this.label21.TabIndex = 41;
            this.label21.Text = "Trip Date";
            this.label21.UseWaitCursor = true;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(82, 102);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(65, 13);
            this.label22.TabIndex = 40;
            this.label22.Text = "Trip Number";
            this.label22.UseWaitCursor = true;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(242, 46);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(23, 13);
            this.label23.TabIndex = 39;
            this.label23.Text = "To:";
            this.label23.UseWaitCursor = true;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(103, 46);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(33, 13);
            this.label24.TabIndex = 38;
            this.label24.Text = "From:";
            this.label24.UseWaitCursor = true;
            // 
            // Cancel_TripNotextBox
            // 
            this.Cancel_TripNotextBox.Location = new System.Drawing.Point(148, 100);
            this.Cancel_TripNotextBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Cancel_TripNotextBox.Name = "Cancel_TripNotextBox";
            this.Cancel_TripNotextBox.ReadOnly = true;
            this.Cancel_TripNotextBox.Size = new System.Drawing.Size(76, 20);
            this.Cancel_TripNotextBox.TabIndex = 34;
            this.Cancel_TripNotextBox.UseWaitCursor = true;
            // 
            // UpdateTripGroupBox
            // 
            this.UpdateTripGroupBox.Controls.Add(this.UPdate_Date);
            this.UpdateTripGroupBox.Controls.Add(this.Type_Update);
            this.UpdateTripGroupBox.Controls.Add(this.UpdateButton);
            this.UpdateTripGroupBox.Controls.Add(this.label9);
            this.UpdateTripGroupBox.Controls.Add(this.Update__arrival);
            this.UpdateTripGroupBox.Controls.Add(this.label10);
            this.UpdateTripGroupBox.Controls.Add(this.Update_departure);
            this.UpdateTripGroupBox.Controls.Add(this.Update_from);
            this.UpdateTripGroupBox.Controls.Add(this.Update_to);
            this.UpdateTripGroupBox.Controls.Add(this.label11);
            this.UpdateTripGroupBox.Controls.Add(this.Update_price);
            this.UpdateTripGroupBox.Controls.Add(this.label12);
            this.UpdateTripGroupBox.Controls.Add(this.label13);
            this.UpdateTripGroupBox.Controls.Add(this.label14);
            this.UpdateTripGroupBox.Controls.Add(this.label15);
            this.UpdateTripGroupBox.Controls.Add(this.Update_tripNo);
            this.UpdateTripGroupBox.Cursor = System.Windows.Forms.Cursors.Default;
            this.UpdateTripGroupBox.Location = new System.Drawing.Point(117, 10);
            this.UpdateTripGroupBox.Name = "UpdateTripGroupBox";
            this.UpdateTripGroupBox.Size = new System.Drawing.Size(654, 426);
            this.UpdateTripGroupBox.TabIndex = 53;
            this.UpdateTripGroupBox.TabStop = false;
            this.UpdateTripGroupBox.Text = "Update Trip";
            // 
            // UPdate_Date
            // 
            this.UPdate_Date.Location = new System.Drawing.Point(389, 111);
            this.UPdate_Date.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.UPdate_Date.Name = "UPdate_Date";
            this.UPdate_Date.Size = new System.Drawing.Size(151, 20);
            this.UPdate_Date.TabIndex = 54;
            this.UPdate_Date.UseWaitCursor = true;
            // 
            // Type_Update
            // 
            this.Type_Update.Controls.Add(this.Economic_Updatebutton);
            this.Type_Update.Controls.Add(this.Business_Updatebutton);
            this.Type_Update.Location = new System.Drawing.Point(358, 20);
            this.Type_Update.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Type_Update.Name = "Type_Update";
            this.Type_Update.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Type_Update.Size = new System.Drawing.Size(150, 81);
            this.Type_Update.TabIndex = 53;
            this.Type_Update.TabStop = false;
            this.Type_Update.Text = "Type(Bussiness/Economic)";
            this.Type_Update.UseWaitCursor = true;
            // 
            // Economic_Updatebutton
            // 
            this.Economic_Updatebutton.BackColor = System.Drawing.Color.CadetBlue;
            this.Economic_Updatebutton.FlatAppearance.BorderSize = 0;
            this.Economic_Updatebutton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.Economic_Updatebutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Economic_Updatebutton.ForeColor = System.Drawing.Color.White;
            this.Economic_Updatebutton.Location = new System.Drawing.Point(78, 29);
            this.Economic_Updatebutton.Name = "Economic_Updatebutton";
            this.Economic_Updatebutton.Size = new System.Drawing.Size(64, 37);
            this.Economic_Updatebutton.TabIndex = 31;
            this.Economic_Updatebutton.Text = "Economic";
            this.Economic_Updatebutton.UseVisualStyleBackColor = false;
            this.Economic_Updatebutton.UseWaitCursor = true;
            this.Economic_Updatebutton.Click += new System.EventHandler(this.Economic_Updatebutton_Click);
            // 
            // Business_Updatebutton
            // 
            this.Business_Updatebutton.BackColor = System.Drawing.Color.CadetBlue;
            this.Business_Updatebutton.FlatAppearance.BorderSize = 0;
            this.Business_Updatebutton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.Business_Updatebutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Business_Updatebutton.ForeColor = System.Drawing.Color.White;
            this.Business_Updatebutton.Location = new System.Drawing.Point(8, 29);
            this.Business_Updatebutton.Name = "Business_Updatebutton";
            this.Business_Updatebutton.Size = new System.Drawing.Size(64, 37);
            this.Business_Updatebutton.TabIndex = 30;
            this.Business_Updatebutton.Text = "Business";
            this.Business_Updatebutton.UseVisualStyleBackColor = false;
            this.Business_Updatebutton.UseWaitCursor = true;
            this.Business_Updatebutton.Click += new System.EventHandler(this.Business_Updatebutton_Click);
            // 
            // UpdateButton
            // 
            this.UpdateButton.BackColor = System.Drawing.Color.Navy;
            this.UpdateButton.FlatAppearance.BorderSize = 0;
            this.UpdateButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.UpdateButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.UpdateButton.ForeColor = System.Drawing.Color.White;
            this.UpdateButton.Location = new System.Drawing.Point(212, 247);
            this.UpdateButton.Name = "UpdateButton";
            this.UpdateButton.Size = new System.Drawing.Size(96, 38);
            this.UpdateButton.TabIndex = 52;
            this.UpdateButton.Text = "Update";
            this.UpdateButton.UseVisualStyleBackColor = false;
            this.UpdateButton.UseWaitCursor = true;
            this.UpdateButton.Click += new System.EventHandler(this.UpdateButton_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(159, 168);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(58, 13);
            this.label9.TabIndex = 51;
            this.label9.Text = "Arrival time";
            this.label9.UseWaitCursor = true;
            // 
            // Update__arrival
            // 
            this.Update__arrival.Location = new System.Drawing.Point(220, 164);
            this.Update__arrival.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Update__arrival.Name = "Update__arrival";
            this.Update__arrival.ReadOnly = true;
            this.Update__arrival.Size = new System.Drawing.Size(76, 20);
            this.Update__arrival.TabIndex = 50;
            this.Update__arrival.UseWaitCursor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(2, 167);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(76, 13);
            this.label10.TabIndex = 49;
            this.label10.Text = "Departure time";
            this.label10.UseWaitCursor = true;
            // 
            // Update_departure
            // 
            this.Update_departure.Location = new System.Drawing.Point(79, 165);
            this.Update_departure.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Update_departure.Name = "Update_departure";
            this.Update_departure.ReadOnly = true;
            this.Update_departure.Size = new System.Drawing.Size(76, 20);
            this.Update_departure.TabIndex = 48;
            this.Update_departure.UseWaitCursor = true;
            // 
            // Update_from
            // 
            this.Update_from.Location = new System.Drawing.Point(78, 53);
            this.Update_from.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Update_from.Name = "Update_from";
            this.Update_from.ReadOnly = true;
            this.Update_from.Size = new System.Drawing.Size(76, 20);
            this.Update_from.TabIndex = 47;
            this.Update_from.UseWaitCursor = true;
            // 
            // Update_to
            // 
            this.Update_to.Location = new System.Drawing.Point(220, 53);
            this.Update_to.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Update_to.Name = "Update_to";
            this.Update_to.ReadOnly = true;
            this.Update_to.Size = new System.Drawing.Size(76, 20);
            this.Update_to.TabIndex = 46;
            this.Update_to.UseWaitCursor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(174, 112);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(31, 13);
            this.label11.TabIndex = 45;
            this.label11.Text = "Price";
            this.label11.UseWaitCursor = true;
            // 
            // Update_price
            // 
            this.Update_price.Location = new System.Drawing.Point(220, 110);
            this.Update_price.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Update_price.Name = "Update_price";
            this.Update_price.ReadOnly = true;
            this.Update_price.Size = new System.Drawing.Size(76, 20);
            this.Update_price.TabIndex = 44;
            this.Update_price.UseWaitCursor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(334, 114);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(51, 13);
            this.label12.TabIndex = 41;
            this.label12.Text = "Trip Date";
            this.label12.UseWaitCursor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(9, 112);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 13);
            this.label13.TabIndex = 40;
            this.label13.Text = "Trip Number";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(182, 54);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(23, 13);
            this.label14.TabIndex = 39;
            this.label14.Text = "To:";
            this.label14.UseWaitCursor = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(40, 54);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(33, 13);
            this.label15.TabIndex = 38;
            this.label15.Text = "From:";
            this.label15.UseWaitCursor = true;
            // 
            // Update_tripNo
            // 
            this.Update_tripNo.Location = new System.Drawing.Point(79, 111);
            this.Update_tripNo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Update_tripNo.Name = "Update_tripNo";
            this.Update_tripNo.ReadOnly = true;
            this.Update_tripNo.Size = new System.Drawing.Size(76, 20);
            this.Update_tripNo.TabIndex = 34;
            this.Update_tripNo.UseWaitCursor = true;
            // 
            // Upcoming_groupBox
            // 
            this.Upcoming_groupBox.Controls.Add(this.groupBox3);
            this.Upcoming_groupBox.Controls.Add(this.UpdateTrainInfoButton);
            this.Upcoming_groupBox.Controls.Add(this.groupBox4);
            this.Upcoming_groupBox.Location = new System.Drawing.Point(117, 10);
            this.Upcoming_groupBox.Name = "Upcoming_groupBox";
            this.Upcoming_groupBox.Size = new System.Drawing.Size(663, 407);
            this.Upcoming_groupBox.TabIndex = 57;
            this.Upcoming_groupBox.TabStop = false;
            this.Upcoming_groupBox.Text = "Upcoming Trip";
            this.Upcoming_groupBox.Visible = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.Upcoming_Train_No_TextBox);
            this.groupBox3.Controls.Add(this.label34);
            this.groupBox3.Controls.Add(this.BusinessgroupBox);
            this.groupBox3.Controls.Add(this.EconomicgroupBox);
            this.groupBox3.Location = new System.Drawing.Point(58, 206);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox3.Size = new System.Drawing.Size(382, 140);
            this.groupBox3.TabIndex = 69;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Train Info";
            this.groupBox3.UseWaitCursor = true;
            // 
            // Upcoming_Train_No_TextBox
            // 
            this.Upcoming_Train_No_TextBox.Location = new System.Drawing.Point(184, 17);
            this.Upcoming_Train_No_TextBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Upcoming_Train_No_TextBox.Name = "Upcoming_Train_No_TextBox";
            this.Upcoming_Train_No_TextBox.ReadOnly = true;
            this.Upcoming_Train_No_TextBox.Size = new System.Drawing.Size(76, 20);
            this.Upcoming_Train_No_TextBox.TabIndex = 69;
            this.Upcoming_Train_No_TextBox.UseWaitCursor = true;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(111, 17);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(71, 13);
            this.label34.TabIndex = 70;
            this.label34.Text = "Train Number";
            this.label34.UseWaitCursor = true;
            // 
            // BusinessgroupBox
            // 
            this.BusinessgroupBox.Controls.Add(this.Upcoming_BusinessPrice);
            this.BusinessgroupBox.Controls.Add(this.label35);
            this.BusinessgroupBox.Controls.Add(this.Upcoming_businessSeatsLeft);
            this.BusinessgroupBox.Controls.Add(this.label36);
            this.BusinessgroupBox.Location = new System.Drawing.Point(22, 54);
            this.BusinessgroupBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BusinessgroupBox.Name = "BusinessgroupBox";
            this.BusinessgroupBox.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BusinessgroupBox.Size = new System.Drawing.Size(150, 81);
            this.BusinessgroupBox.TabIndex = 67;
            this.BusinessgroupBox.TabStop = false;
            this.BusinessgroupBox.Text = "Business";
            this.BusinessgroupBox.UseWaitCursor = true;
            // 
            // Upcoming_BusinessPrice
            // 
            this.Upcoming_BusinessPrice.Location = new System.Drawing.Point(64, 17);
            this.Upcoming_BusinessPrice.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Upcoming_BusinessPrice.Name = "Upcoming_BusinessPrice";
            this.Upcoming_BusinessPrice.ReadOnly = true;
            this.Upcoming_BusinessPrice.Size = new System.Drawing.Size(76, 20);
            this.Upcoming_BusinessPrice.TabIndex = 62;
            this.Upcoming_BusinessPrice.UseWaitCursor = true;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(28, 17);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(31, 13);
            this.label35.TabIndex = 63;
            this.label35.Text = "Price";
            this.label35.UseWaitCursor = true;
            // 
            // Upcoming_businessSeatsLeft
            // 
            this.Upcoming_businessSeatsLeft.Location = new System.Drawing.Point(64, 46);
            this.Upcoming_businessSeatsLeft.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Upcoming_businessSeatsLeft.Name = "Upcoming_businessSeatsLeft";
            this.Upcoming_businessSeatsLeft.ReadOnly = true;
            this.Upcoming_businessSeatsLeft.Size = new System.Drawing.Size(76, 20);
            this.Upcoming_businessSeatsLeft.TabIndex = 60;
            this.Upcoming_businessSeatsLeft.UseWaitCursor = true;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(7, 46);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(55, 13);
            this.label36.TabIndex = 61;
            this.label36.Text = "Seats Left";
            this.label36.UseWaitCursor = true;
            // 
            // EconomicgroupBox
            // 
            this.EconomicgroupBox.Controls.Add(this.Upcoming_EconomicPrice);
            this.EconomicgroupBox.Controls.Add(this.label37);
            this.EconomicgroupBox.Controls.Add(this.Upcoming_EconomicSeatsLeft);
            this.EconomicgroupBox.Controls.Add(this.label38);
            this.EconomicgroupBox.Location = new System.Drawing.Point(199, 54);
            this.EconomicgroupBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.EconomicgroupBox.Name = "EconomicgroupBox";
            this.EconomicgroupBox.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.EconomicgroupBox.Size = new System.Drawing.Size(150, 81);
            this.EconomicgroupBox.TabIndex = 68;
            this.EconomicgroupBox.TabStop = false;
            this.EconomicgroupBox.Text = "Economic";
            this.EconomicgroupBox.UseWaitCursor = true;
            // 
            // Upcoming_EconomicPrice
            // 
            this.Upcoming_EconomicPrice.Location = new System.Drawing.Point(64, 17);
            this.Upcoming_EconomicPrice.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Upcoming_EconomicPrice.Name = "Upcoming_EconomicPrice";
            this.Upcoming_EconomicPrice.ReadOnly = true;
            this.Upcoming_EconomicPrice.Size = new System.Drawing.Size(76, 20);
            this.Upcoming_EconomicPrice.TabIndex = 62;
            this.Upcoming_EconomicPrice.UseWaitCursor = true;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(28, 17);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(31, 13);
            this.label37.TabIndex = 63;
            this.label37.Text = "Price";
            this.label37.UseWaitCursor = true;
            // 
            // Upcoming_EconomicSeatsLeft
            // 
            this.Upcoming_EconomicSeatsLeft.Location = new System.Drawing.Point(64, 46);
            this.Upcoming_EconomicSeatsLeft.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Upcoming_EconomicSeatsLeft.Name = "Upcoming_EconomicSeatsLeft";
            this.Upcoming_EconomicSeatsLeft.ReadOnly = true;
            this.Upcoming_EconomicSeatsLeft.Size = new System.Drawing.Size(76, 20);
            this.Upcoming_EconomicSeatsLeft.TabIndex = 60;
            this.Upcoming_EconomicSeatsLeft.UseWaitCursor = true;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(7, 46);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(55, 13);
            this.label38.TabIndex = 61;
            this.label38.Text = "Seats Left";
            this.label38.UseWaitCursor = true;
            // 
            // UpdateTrainInfoButton
            // 
            this.UpdateTrainInfoButton.BackColor = System.Drawing.Color.Navy;
            this.UpdateTrainInfoButton.FlatAppearance.BorderSize = 0;
            this.UpdateTrainInfoButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.UpdateTrainInfoButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.UpdateTrainInfoButton.ForeColor = System.Drawing.Color.White;
            this.UpdateTrainInfoButton.Location = new System.Drawing.Point(242, 366);
            this.UpdateTrainInfoButton.Name = "UpdateTrainInfoButton";
            this.UpdateTrainInfoButton.Size = new System.Drawing.Size(130, 41);
            this.UpdateTrainInfoButton.TabIndex = 56;
            this.UpdateTrainInfoButton.Text = "Update Train Info";
            this.UpdateTrainInfoButton.UseVisualStyleBackColor = false;
            this.UpdateTrainInfoButton.UseWaitCursor = true;
            this.UpdateTrainInfoButton.Click += new System.EventHandler(this.UpdateTrainInfoButton_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.Upcoming_Tripdate);
            this.groupBox4.Controls.Add(this.Upcoming_Type);
            this.groupBox4.Controls.Add(this.label39);
            this.groupBox4.Controls.Add(this.Upcoming_Arrival);
            this.groupBox4.Controls.Add(this.label40);
            this.groupBox4.Controls.Add(this.Upcoming_Departure);
            this.groupBox4.Controls.Add(this.Upcoming_From);
            this.groupBox4.Controls.Add(this.Upcoming_To);
            this.groupBox4.Controls.Add(this.label41);
            this.groupBox4.Controls.Add(this.Upcoming_price);
            this.groupBox4.Controls.Add(this.label42);
            this.groupBox4.Controls.Add(this.label43);
            this.groupBox4.Controls.Add(this.label44);
            this.groupBox4.Controls.Add(this.label45);
            this.groupBox4.Controls.Add(this.label46);
            this.groupBox4.Controls.Add(this.Upcoming_TripNo);
            this.groupBox4.Location = new System.Drawing.Point(58, 19);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(544, 170);
            this.groupBox4.TabIndex = 55;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Trip Info";
            this.groupBox4.UseWaitCursor = true;
            // 
            // Upcoming_Tripdate
            // 
            this.Upcoming_Tripdate.Enabled = false;
            this.Upcoming_Tripdate.Location = new System.Drawing.Point(382, 75);
            this.Upcoming_Tripdate.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Upcoming_Tripdate.Name = "Upcoming_Tripdate";
            this.Upcoming_Tripdate.Size = new System.Drawing.Size(151, 20);
            this.Upcoming_Tripdate.TabIndex = 69;
            this.Upcoming_Tripdate.UseWaitCursor = true;
            // 
            // Upcoming_Type
            // 
            this.Upcoming_Type.Location = new System.Drawing.Point(382, 17);
            this.Upcoming_Type.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Upcoming_Type.Name = "Upcoming_Type";
            this.Upcoming_Type.ReadOnly = true;
            this.Upcoming_Type.Size = new System.Drawing.Size(76, 20);
            this.Upcoming_Type.TabIndex = 68;
            this.Upcoming_Type.UseWaitCursor = true;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(240, 135);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(58, 13);
            this.label39.TabIndex = 67;
            this.label39.Text = "Arrival time";
            this.label39.UseWaitCursor = true;
            // 
            // Upcoming_Arrival
            // 
            this.Upcoming_Arrival.Location = new System.Drawing.Point(304, 131);
            this.Upcoming_Arrival.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Upcoming_Arrival.Name = "Upcoming_Arrival";
            this.Upcoming_Arrival.ReadOnly = true;
            this.Upcoming_Arrival.Size = new System.Drawing.Size(76, 20);
            this.Upcoming_Arrival.TabIndex = 66;
            this.Upcoming_Arrival.UseWaitCursor = true;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(72, 132);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(76, 13);
            this.label40.TabIndex = 65;
            this.label40.Text = "Departure time";
            this.label40.UseWaitCursor = true;
            // 
            // Upcoming_Departure
            // 
            this.Upcoming_Departure.Location = new System.Drawing.Point(153, 132);
            this.Upcoming_Departure.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Upcoming_Departure.Name = "Upcoming_Departure";
            this.Upcoming_Departure.ReadOnly = true;
            this.Upcoming_Departure.Size = new System.Drawing.Size(76, 20);
            this.Upcoming_Departure.TabIndex = 64;
            this.Upcoming_Departure.UseWaitCursor = true;
            // 
            // Upcoming_From
            // 
            this.Upcoming_From.Location = new System.Drawing.Point(117, 22);
            this.Upcoming_From.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Upcoming_From.Name = "Upcoming_From";
            this.Upcoming_From.ReadOnly = true;
            this.Upcoming_From.Size = new System.Drawing.Size(76, 20);
            this.Upcoming_From.TabIndex = 63;
            this.Upcoming_From.UseWaitCursor = true;
            // 
            // Upcoming_To
            // 
            this.Upcoming_To.Location = new System.Drawing.Point(248, 20);
            this.Upcoming_To.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Upcoming_To.Name = "Upcoming_To";
            this.Upcoming_To.ReadOnly = true;
            this.Upcoming_To.Size = new System.Drawing.Size(76, 20);
            this.Upcoming_To.TabIndex = 62;
            this.Upcoming_To.UseWaitCursor = true;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(212, 80);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(31, 13);
            this.label41.TabIndex = 61;
            this.label41.Text = "Price";
            this.label41.UseWaitCursor = true;
            // 
            // Upcoming_price
            // 
            this.Upcoming_price.Location = new System.Drawing.Point(248, 76);
            this.Upcoming_price.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Upcoming_price.Name = "Upcoming_price";
            this.Upcoming_price.ReadOnly = true;
            this.Upcoming_price.Size = new System.Drawing.Size(76, 20);
            this.Upcoming_price.TabIndex = 60;
            this.Upcoming_price.UseWaitCursor = true;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(340, 20);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(31, 13);
            this.label42.TabIndex = 59;
            this.label42.Text = "Type";
            this.label42.UseWaitCursor = true;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(328, 76);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(51, 13);
            this.label43.TabIndex = 58;
            this.label43.Text = "Trip Date";
            this.label43.UseWaitCursor = true;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(52, 80);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(65, 13);
            this.label44.TabIndex = 57;
            this.label44.Text = "Trip Number";
            this.label44.UseWaitCursor = true;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(212, 24);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(23, 13);
            this.label45.TabIndex = 56;
            this.label45.Text = "To:";
            this.label45.UseWaitCursor = true;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(72, 24);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(33, 13);
            this.label46.TabIndex = 55;
            this.label46.Text = "From:";
            this.label46.UseWaitCursor = true;
            // 
            // Upcoming_TripNo
            // 
            this.Upcoming_TripNo.Location = new System.Drawing.Point(117, 78);
            this.Upcoming_TripNo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Upcoming_TripNo.Name = "Upcoming_TripNo";
            this.Upcoming_TripNo.ReadOnly = true;
            this.Upcoming_TripNo.Size = new System.Drawing.Size(76, 20);
            this.Upcoming_TripNo.TabIndex = 53;
            this.Upcoming_TripNo.UseWaitCursor = true;
            // 
            // PreviousgroupBox
            // 
            this.PreviousgroupBox.Controls.Add(this.Previous_tripDate);
            this.PreviousgroupBox.Controls.Add(this.FeedbackGroupBox);
            this.PreviousgroupBox.Controls.Add(this.dataGridView1);
            this.PreviousgroupBox.Controls.Add(this.Previous_Type);
            this.PreviousgroupBox.Controls.Add(this.label28);
            this.PreviousgroupBox.Controls.Add(this.Previous_Arrival);
            this.PreviousgroupBox.Controls.Add(this.label26);
            this.PreviousgroupBox.Controls.Add(this.Previous_Departure);
            this.PreviousgroupBox.Controls.Add(this.Previous_From_Textbox);
            this.PreviousgroupBox.Controls.Add(this.Previous_to_Textbox);
            this.PreviousgroupBox.Controls.Add(this.label27);
            this.PreviousgroupBox.Controls.Add(this.Previous_Price);
            this.PreviousgroupBox.Controls.Add(this.label29);
            this.PreviousgroupBox.Controls.Add(this.label30);
            this.PreviousgroupBox.Controls.Add(this.label31);
            this.PreviousgroupBox.Controls.Add(this.label32);
            this.PreviousgroupBox.Controls.Add(this.label33);
            this.PreviousgroupBox.Controls.Add(this.Previous_tripNo);
            this.PreviousgroupBox.Location = new System.Drawing.Point(117, 10);
            this.PreviousgroupBox.Name = "PreviousgroupBox";
            this.PreviousgroupBox.Size = new System.Drawing.Size(667, 419);
            this.PreviousgroupBox.TabIndex = 55;
            this.PreviousgroupBox.TabStop = false;
            this.PreviousgroupBox.Text = "Previous Trips";
            // 
            // Previous_tripDate
            // 
            this.Previous_tripDate.Enabled = false;
            this.Previous_tripDate.Location = new System.Drawing.Point(220, 236);
            this.Previous_tripDate.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Previous_tripDate.Name = "Previous_tripDate";
            this.Previous_tripDate.Size = new System.Drawing.Size(151, 20);
            this.Previous_tripDate.TabIndex = 56;
            this.Previous_tripDate.UseWaitCursor = true;
            // 
            // FeedbackGroupBox
            // 
            this.FeedbackGroupBox.Controls.Add(this.label25);
            this.FeedbackGroupBox.Controls.Add(this.RatingCombo);
            this.FeedbackGroupBox.Controls.Add(this.RatingLabel);
            this.FeedbackGroupBox.Controls.Add(this.CommentTextBox);
            this.FeedbackGroupBox.Controls.Add(this.AddFeedbackButton);
            this.FeedbackGroupBox.Location = new System.Drawing.Point(385, 198);
            this.FeedbackGroupBox.Name = "FeedbackGroupBox";
            this.FeedbackGroupBox.Size = new System.Drawing.Size(245, 173);
            this.FeedbackGroupBox.TabIndex = 55;
            this.FeedbackGroupBox.TabStop = false;
            this.FeedbackGroupBox.Text = "Feedback";
            this.FeedbackGroupBox.UseWaitCursor = true;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(32, 67);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(51, 13);
            this.label25.TabIndex = 17;
            this.label25.Text = "Comment";
            this.label25.UseWaitCursor = true;
            // 
            // RatingCombo
            // 
            this.RatingCombo.FormattingEnabled = true;
            this.RatingCombo.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.RatingCombo.Location = new System.Drawing.Point(90, 24);
            this.RatingCombo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.RatingCombo.MaxLength = 1;
            this.RatingCombo.Name = "RatingCombo";
            this.RatingCombo.Size = new System.Drawing.Size(92, 21);
            this.RatingCombo.TabIndex = 16;
            this.RatingCombo.UseWaitCursor = true;
            // 
            // RatingLabel
            // 
            this.RatingLabel.AutoSize = true;
            this.RatingLabel.Location = new System.Drawing.Point(35, 25);
            this.RatingLabel.Name = "RatingLabel";
            this.RatingLabel.Size = new System.Drawing.Size(38, 13);
            this.RatingLabel.TabIndex = 10;
            this.RatingLabel.Text = "Rating";
            this.RatingLabel.UseWaitCursor = true;
            // 
            // CommentTextBox
            // 
            this.CommentTextBox.Location = new System.Drawing.Point(87, 67);
            this.CommentTextBox.Name = "CommentTextBox";
            this.CommentTextBox.Size = new System.Drawing.Size(153, 20);
            this.CommentTextBox.TabIndex = 7;
            this.CommentTextBox.UseWaitCursor = true;
            // 
            // AddFeedbackButton
            // 
            this.AddFeedbackButton.BackColor = System.Drawing.Color.Navy;
            this.AddFeedbackButton.FlatAppearance.BorderSize = 0;
            this.AddFeedbackButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.AddFeedbackButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddFeedbackButton.ForeColor = System.Drawing.Color.White;
            this.AddFeedbackButton.Location = new System.Drawing.Point(55, 119);
            this.AddFeedbackButton.Name = "AddFeedbackButton";
            this.AddFeedbackButton.Size = new System.Drawing.Size(134, 37);
            this.AddFeedbackButton.TabIndex = 8;
            this.AddFeedbackButton.Text = "Add FeedBack";
            this.AddFeedbackButton.UseVisualStyleBackColor = false;
            this.AddFeedbackButton.UseWaitCursor = true;
            this.AddFeedbackButton.Click += new System.EventHandler(this.AddFeedbackButton_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(6, 19);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(659, 163);
            this.dataGridView1.TabIndex = 53;
            this.dataGridView1.UseWaitCursor = true;
            this.dataGridView1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.RowHeaderMouseClick);
            // 
            // Previous_Type
            // 
            this.Previous_Type.Location = new System.Drawing.Point(82, 288);
            this.Previous_Type.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Previous_Type.Name = "Previous_Type";
            this.Previous_Type.ReadOnly = true;
            this.Previous_Type.Size = new System.Drawing.Size(76, 20);
            this.Previous_Type.TabIndex = 52;
            this.Previous_Type.UseWaitCursor = true;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(160, 268);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(58, 13);
            this.label28.TabIndex = 51;
            this.label28.Text = "Arrival time";
            this.label28.UseWaitCursor = true;
            // 
            // Previous_Arrival
            // 
            this.Previous_Arrival.Location = new System.Drawing.Point(220, 266);
            this.Previous_Arrival.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Previous_Arrival.Name = "Previous_Arrival";
            this.Previous_Arrival.ReadOnly = true;
            this.Previous_Arrival.Size = new System.Drawing.Size(76, 20);
            this.Previous_Arrival.TabIndex = 50;
            this.Previous_Arrival.UseWaitCursor = true;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(2, 266);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(76, 13);
            this.label26.TabIndex = 49;
            this.label26.Text = "Departure time";
            this.label26.UseWaitCursor = true;
            // 
            // Previous_Departure
            // 
            this.Previous_Departure.Location = new System.Drawing.Point(82, 266);
            this.Previous_Departure.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Previous_Departure.Name = "Previous_Departure";
            this.Previous_Departure.ReadOnly = true;
            this.Previous_Departure.Size = new System.Drawing.Size(76, 20);
            this.Previous_Departure.TabIndex = 48;
            this.Previous_Departure.UseWaitCursor = true;
            // 
            // Previous_From_Textbox
            // 
            this.Previous_From_Textbox.Location = new System.Drawing.Point(82, 213);
            this.Previous_From_Textbox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Previous_From_Textbox.Name = "Previous_From_Textbox";
            this.Previous_From_Textbox.ReadOnly = true;
            this.Previous_From_Textbox.Size = new System.Drawing.Size(76, 20);
            this.Previous_From_Textbox.TabIndex = 47;
            this.Previous_From_Textbox.UseWaitCursor = true;
            // 
            // Previous_to_Textbox
            // 
            this.Previous_to_Textbox.Location = new System.Drawing.Point(220, 210);
            this.Previous_to_Textbox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Previous_to_Textbox.Name = "Previous_to_Textbox";
            this.Previous_to_Textbox.ReadOnly = true;
            this.Previous_to_Textbox.Size = new System.Drawing.Size(76, 20);
            this.Previous_to_Textbox.TabIndex = 46;
            this.Previous_to_Textbox.UseWaitCursor = true;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(176, 292);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(31, 13);
            this.label27.TabIndex = 45;
            this.label27.Text = "Price";
            this.label27.UseWaitCursor = true;
            // 
            // Previous_Price
            // 
            this.Previous_Price.Location = new System.Drawing.Point(220, 288);
            this.Previous_Price.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Previous_Price.Name = "Previous_Price";
            this.Previous_Price.ReadOnly = true;
            this.Previous_Price.Size = new System.Drawing.Size(76, 20);
            this.Previous_Price.TabIndex = 44;
            this.Previous_Price.UseWaitCursor = true;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(47, 291);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(31, 13);
            this.label29.TabIndex = 43;
            this.label29.Text = "Type";
            this.label29.UseWaitCursor = true;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(164, 240);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(51, 13);
            this.label30.TabIndex = 41;
            this.label30.Text = "Trip Date";
            this.label30.UseWaitCursor = true;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(12, 240);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(65, 13);
            this.label31.TabIndex = 40;
            this.label31.Text = "Trip Number";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(193, 213);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(23, 13);
            this.label32.TabIndex = 39;
            this.label32.Text = "To:";
            this.label32.UseWaitCursor = true;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(44, 214);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(33, 13);
            this.label33.TabIndex = 38;
            this.label33.Text = "From:";
            this.label33.UseWaitCursor = true;
            // 
            // Previous_tripNo
            // 
            this.Previous_tripNo.Location = new System.Drawing.Point(82, 240);
            this.Previous_tripNo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Previous_tripNo.Name = "Previous_tripNo";
            this.Previous_tripNo.ReadOnly = true;
            this.Previous_tripNo.Size = new System.Drawing.Size(76, 20);
            this.Previous_tripNo.TabIndex = 34;
            this.Previous_tripNo.UseWaitCursor = true;
            // 
            // Passenger_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(794, 443);
            this.Controls.Add(this.CancelTripsButton);
            this.Controls.Add(this.Change_Trips_Button);
            this.Controls.Add(this.Previous_Trips);
            this.Controls.Add(this.Upcoming_Trips);
            this.Controls.Add(this.Book_Trips);
            this.Controls.Add(this.PreviousgroupBox);
            this.Controls.Add(this.Upcoming_groupBox);
            this.Controls.Add(this.CancelBookgroupBox);
            this.Controls.Add(this.Book_TripsGroupBox);
            this.Controls.Add(this.UpdateTripGroupBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Passenger_Form";
            this.Text = "Passenger Form";
            this.Book_TripsGroupBox.ResumeLayout(false);
            this.TypeGroupBox.ResumeLayout(false);
            this.TypeGroupBox.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.scheduleDataGridView)).EndInit();
            this.CancelBookgroupBox.ResumeLayout(false);
            this.CancelBookgroupBox.PerformLayout();
            this.UpdateTripGroupBox.ResumeLayout(false);
            this.UpdateTripGroupBox.PerformLayout();
            this.Type_Update.ResumeLayout(false);
            this.Upcoming_groupBox.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.BusinessgroupBox.ResumeLayout(false);
            this.BusinessgroupBox.PerformLayout();
            this.EconomicgroupBox.ResumeLayout(false);
            this.EconomicgroupBox.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.PreviousgroupBox.ResumeLayout(false);
            this.PreviousgroupBox.PerformLayout();
            this.FeedbackGroupBox.ResumeLayout(false);
            this.FeedbackGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button CancelTripsButton;
        private System.Windows.Forms.Button Change_Trips_Button;
        private System.Windows.Forms.Button Previous_Trips;
        private System.Windows.Forms.Button Upcoming_Trips;
        private System.Windows.Forms.Button Book_Trips;
        private System.Windows.Forms.GroupBox Book_TripsGroupBox;
        private System.Windows.Forms.GroupBox TypeGroupBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox Booktrip_SeatsLeftTextBox;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button Booktrip_Economicbutton;
        private System.Windows.Forms.Button Booktrip_Businessbutton;
        private System.Windows.Forms.Button Booktrip_BookButton;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox Booktrip_ArrivaltextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Booktrip_DeparturetextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Booktrip_PriceTextBox;
        private System.Windows.Forms.Button Booktrip_Show_All_Available_Tripsbutton;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox Booktrip_to;
        private System.Windows.Forms.ComboBox Booktrip_From;
        private System.Windows.Forms.TextBox Booktrip_TripNoTextBox;
        private System.Windows.Forms.Button Booktrip_SearchButton;
        private System.Windows.Forms.DataGridView scheduleDataGridView;
        private System.Windows.Forms.GroupBox CancelBookgroupBox;
        private System.Windows.Forms.TextBox Cancel_TypetextBox;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button Cancel_ContinueButton;
        private System.Windows.Forms.TextBox Cancel_ArrivaltextBox;
        private System.Windows.Forms.Button Cancel_CancelButton;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox Cancel_DeparturetextBox;
        private System.Windows.Forms.TextBox Cancel_FromtextBox;
        private System.Windows.Forms.TextBox Cancel_TotextBox;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox Cancel_PricetextBox;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox Cancel_TripNotextBox;
        private System.Windows.Forms.GroupBox UpdateTripGroupBox;
        private System.Windows.Forms.GroupBox PreviousgroupBox;
        private System.Windows.Forms.GroupBox FeedbackGroupBox;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox RatingCombo;
        private System.Windows.Forms.Label RatingLabel;
        private System.Windows.Forms.TextBox CommentTextBox;
        private System.Windows.Forms.Button AddFeedbackButton;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox Previous_Type;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox Previous_Arrival;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox Previous_Departure;
        private System.Windows.Forms.TextBox Previous_From_Textbox;
        private System.Windows.Forms.TextBox Previous_to_Textbox;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox Previous_Price;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox Previous_tripNo;
        private System.Windows.Forms.GroupBox Type_Update;
        private System.Windows.Forms.Button Economic_Updatebutton;
        private System.Windows.Forms.Button Business_Updatebutton;
        private System.Windows.Forms.Button UpdateButton;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox Update__arrival;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox Update_departure;
        private System.Windows.Forms.TextBox Update_from;
        private System.Windows.Forms.TextBox Update_to;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox Update_price;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox Update_tripNo;
        private System.Windows.Forms.GroupBox Upcoming_groupBox;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox Upcoming_Train_No_TextBox;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.GroupBox BusinessgroupBox;
        private System.Windows.Forms.TextBox Upcoming_BusinessPrice;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox Upcoming_businessSeatsLeft;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.GroupBox EconomicgroupBox;
        private System.Windows.Forms.TextBox Upcoming_EconomicPrice;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox Upcoming_EconomicSeatsLeft;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Button UpdateTrainInfoButton;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox Upcoming_Type;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox Upcoming_Arrival;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox Upcoming_Departure;
        private System.Windows.Forms.TextBox Upcoming_From;
        private System.Windows.Forms.TextBox Upcoming_To;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox Upcoming_price;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox Upcoming_TripNo;
        private System.Windows.Forms.DateTimePicker Previous_tripDate;
        private System.Windows.Forms.DateTimePicker Upcoming_Tripdate;
        private System.Windows.Forms.DateTimePicker UPdate_Date;
        private System.Windows.Forms.DateTimePicker Cancel_TripDatetextBox;
        private System.Windows.Forms.DateTimePicker Booktrip_TripDate;
    }
}